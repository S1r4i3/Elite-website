# Elite B Tax Services — Admin Panel

A standalone admin dashboard with a left sidebar, built to run on its own — no build step,
no npm install, no database. Plain HTML, CSS and JavaScript.

---

## How to run

**Option 1 — VS Code (recommended)**

1. Unzip the folder and open it in VS Code (`File → Open Folder`).
2. Install the **Live Server** extension (by Ritwick Dey) if you don't have it.
3. Right-click `index.html` → **Open with Live Server**.

**Option 2 — any local web server**

```bash
# Python (already on most machines)
python -m http.server 5500

# or Node
npx serve .
```

Then open http://localhost:5500

**Option 3 — no server at all:** double-click `index.html`. Everything works, though saving
data between visits is more reliable when served from a local server.

**Password:** `admin123` — change it in **Settings → Change password**.

---

## What's inside

| Sidebar section | Page | What it does |
|---|---|---|
| Overview | Dashboard | Client/document counts, 6-month upload chart, recent inquiries, newest clients, activity log |
| Clients | All Clients | Search, filter, sort, add, edit, delete; **View** opens a full client profile with their documents |
| Clients | Client Documents | Everything clients uploaded, filtered by tax year |
| Clients | Draft Estimations | Drafts shared with clients, with review status and the client's comments |
| Clients | Final Documents | Completed returns shared with clients |
| Enquiries | Leads | Requests from the website forms, with a status pipeline |
| Enquiries | Website Inquiries | Messages from the website pop-up form |
| Website content | CMS Pages, Home Banners, Services & Pricing, Tax Notes | Editable content lists |
| Administration | Employees, Admin Logs, Settings | Staff accounts, activity history, company details, SEO, password |

Every table has search, sorting, filters, pagination and **CSV export**.
Client IDs are generated automatically in the format `EBT-2026-0001`.

---

## Where the data lives

All data is stored in your browser's `localStorage` under the key `ebt-admin-db-v1`,
seeded with 12 sample clients and their documents. Nothing is sent anywhere.

- Changes you make (add/edit/delete) are saved as you go.
- **Settings → Reset demo data** puts the sample data back.
- Clearing your browser data clears the panel's data too.
- Data is per-browser: it is not shared between computers or with the website.

---

## Connecting it to a real backend

Right now every read and write goes through `DB` in `assets/data.js`. To make this panel
work against a real server, replace the methods in that one file with API calls, for example:

```js
async all(coll)            { return (await fetch(`/api/${coll}`)).json(); }
async insert(coll, row)    { return (await fetch(`/api/${coll}`, { method: "POST", body: JSON.stringify(row) })).json(); }
async update(coll, id, p)  { return (await fetch(`/api/${coll}/${id}`, { method: "PATCH", body: JSON.stringify(p) })).json(); }
async remove(coll, id)     { await fetch(`/api/${coll}/${id}`, { method: "DELETE" }); }
```

The page files (`assets/pages.js`) would then need `await` where they call `DB`.

**Important:** the login here is front-end only — it just compares a password stored in the
browser. It keeps the panel tidy for demos, but it is **not** security. Before putting this
online, the sign-in and every data request must be checked on a server.

File downloads show a reminder message for the same reason: there are no real files to send
until a backend stores them.

---

## Files

```
index.html          the page shell (login + sidebar + topbar)
assets/styles.css   all styling and the brand colors
assets/data.js      demo data + the DB layer (swap this for your API)
assets/ui.js        tables, modals, forms, toasts, CSV export
assets/pages.js     one function per sidebar page
assets/app.js       sidebar menu, router, clocks, login
assets/favicon.svg  browser tab icon
```

Brand colors: red `#C8102E`, dark `#1B1F24`, page background `#F4F5F7`.
