/* Elite B Tax Services — Admin Panel
   Small UI helpers: escaping, formatting, tables, modals, forms, toasts, CSV export. */

const UI = (() => {
  const esc = (v) =>
    String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);

  const fmtDate = (iso) =>
    new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
  const fmtDateTime = (iso) =>
    new Date(iso).toLocaleString(undefined, { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
  const fmtSize = (kb) => (kb >= 1024 ? (kb / 1024).toFixed(1) + " MB" : Math.round(kb) + " KB");
  const initials = (name) =>
    String(name || "")
      .split(" ")
      .map((p) => p[0])
      .join("")
      .slice(0, 2)
      .toUpperCase();

  const BADGES = {
    active: "badge-ok",
    approved: "badge-ok",
    converted: "badge-ok",
    pending: "badge-warn",
    awaiting_review: "badge-brand",
    changes_requested: "badge-warn",
    new: "badge-brand",
    contacted: "badge-info",
    qualified: "badge-info",
    inactive: "badge-muted",
    closed: "badge-muted",
  };
  const LABELS = {
    awaiting_review: "Awaiting client review",
    changes_requested: "Changes requested",
    approved: "Approved by client",
  };
  const badge = (status) =>
    status ? `<span class="badge ${BADGES[status] || "badge-muted"}">${esc(LABELS[status] || status.replace(/_/g, " "))}</span>` : "";

  /* ── Toast ─────────────────────────────────────────── */
  function toast(message, kind) {
    const root = document.getElementById("toast-root");
    const el = document.createElement("div");
    el.className = "toast" + (kind === "error" ? " err" : "");
    el.textContent = message;
    root.appendChild(el);
    setTimeout(() => el.remove(), 3200);
  }

  /* ── Modal ─────────────────────────────────────────── */
  let closeModalFn = null;
  function modal({ title, body, footer, wide, onClose }) {
    closeModal();
    const root = document.getElementById("modal-root");
    const backdrop = document.getElementById("backdrop");
    const wrap = document.createElement("div");
    wrap.className = "modal";
    wrap.innerHTML = `
      <div class="modal-card ${wide ? "wide" : ""}" role="dialog" aria-modal="true" aria-label="${esc(title)}">
        <div class="modal-head">
          <h2>${esc(title)}</h2>
          <button class="icon-btn" style="margin-left:auto" data-close aria-label="Close">✕</button>
        </div>
        <div class="modal-body">${body}</div>
        ${footer ? `<div class="modal-foot">${footer}</div>` : ""}
      </div>`;
    root.appendChild(wrap);
    backdrop.hidden = false;
    document.body.style.overflow = "hidden";

    const close = () => {
      wrap.remove();
      backdrop.hidden = true;
      document.body.style.overflow = "";
      document.removeEventListener("keydown", onKey);
      closeModalFn = null;
      onClose && onClose();
    };
    const onKey = (e) => e.key === "Escape" && close();
    document.addEventListener("keydown", onKey);
    wrap.querySelectorAll("[data-close]").forEach((b) => b.addEventListener("click", close));
    backdrop.onclick = close;
    closeModalFn = close;
    setTimeout(() => wrap.querySelector("input, select, textarea, button")?.focus(), 60);
    return { el: wrap, close };
  }
  const closeModal = () => closeModalFn && closeModalFn();

  function confirmDialog(message, onYes) {
    const m = modal({
      title: "Please confirm",
      body: `<p style="margin:0">${esc(message)}</p>`,
      footer: `<button class="btn btn-secondary" data-close>Cancel</button><button class="btn btn-danger" id="confirm-yes">Delete</button>`,
    });
    m.el.querySelector("#confirm-yes").onclick = () => {
      m.close();
      onYes();
    };
  }

  /* ── Forms ─────────────────────────────────────────── */
  /** fields: [{name,label,type,value,options,required,hint,full}] */
  function formHtml(fields) {
    return `<div class="grid grid-2" style="gap:0 14px">${fields
      .map((f) => {
        const id = "f-" + f.name;
        const common = `id="${id}" name="${esc(f.name)}" ${f.required ? "required" : ""}`;
        let input;
        if (f.type === "select") {
          input = `<select ${common}>${(f.options || [])
            .map((o) => {
              const val = typeof o === "string" ? o : o.value;
              const lab = typeof o === "string" ? o : o.label;
              return `<option value="${esc(val)}" ${String(f.value) === String(val) ? "selected" : ""}>${esc(lab)}</option>`;
            })
            .join("")}</select>`;
        } else if (f.type === "textarea") {
          input = `<textarea ${common} placeholder="${esc(f.placeholder || "")}">${esc(f.value || "")}</textarea>`;
        } else if (f.type === "file") {
          input = `<input type="file" ${common} />`;
        } else {
          input = `<input type="${f.type || "text"}" ${common} value="${esc(f.value ?? "")}" placeholder="${esc(f.placeholder || "")}" />`;
        }
        return `<div class="field" style="${f.full === false ? "" : "grid-column:1/-1"}">
            <label for="${id}">${esc(f.label)}</label>${input}
            ${f.hint ? `<p class="hint">${esc(f.hint)}</p>` : ""}
          </div>`;
      })
      .join("")}</div>`;
  }

  /** Opens a modal form; onSubmit receives a plain object of values. */
  function formModal({ title, fields, submitLabel = "Save", wide, onSubmit }) {
    const m = modal({
      title,
      wide,
      body: `<form id="modal-form">${formHtml(fields)}</form>`,
      footer: `<button class="btn btn-secondary" data-close>Cancel</button><button class="btn btn-primary" id="modal-submit">${esc(submitLabel)}</button>`,
    });
    const form = m.el.querySelector("#modal-form");
    const submit = (e) => {
      e.preventDefault();
      if (!form.reportValidity()) return;
      const data = {};
      fields.forEach((f) => {
        const input = form.elements[f.name];
        if (!input) return;
        data[f.name] = f.type === "file" ? (input.files[0]?.name || "") : input.value.trim();
        if (f.type === "file") data[f.name + "SizeKb"] = input.files[0] ? Math.round(input.files[0].size / 1024) : 0;
      });
      onSubmit(data, m.close);
    };
    form.addEventListener("submit", submit);
    m.el.querySelector("#modal-submit").addEventListener("click", submit);
    return m;
  }

  /* ── Table ─────────────────────────────────────────── */
  const tableState = {};
  /**
   * columns: [{key,label,render(row),sortable,width}]
   * opts: {id, rows, columns, search:[keys], filters:[{key,label,options}], perPage, empty, toolbar}
   */
  function table(opts) {
    const id = opts.id;
    tableState[id] = tableState[id] || { q: "", sort: null, dir: 1, page: 1, filters: {} };
    const st = tableState[id];

    const render = () => {
      let rows = opts.rows.slice();
      if (st.q && opts.search) {
        const q = st.q.toLowerCase();
        rows = rows.filter((r) => opts.search.some((k) => String(r[k] ?? "").toLowerCase().includes(q)));
      }
      Object.entries(st.filters).forEach(([k, v]) => {
        if (v) rows = rows.filter((r) => String(r[k]) === v);
      });
      if (st.sort) {
        rows.sort((a, b) => {
          const x = a[st.sort] ?? "";
          const y = b[st.sort] ?? "";
          return (typeof x === "number" ? x - y : String(x).localeCompare(String(y))) * st.dir;
        });
      }
      const perPage = opts.perPage || 10;
      const pages = Math.max(1, Math.ceil(rows.length / perPage));
      st.page = Math.min(st.page, pages);
      const pageRows = rows.slice((st.page - 1) * perPage, st.page * perPage);

      const filtersHtml = (opts.filters || [])
        .map(
          (f) =>
            `<select class="select-sm" data-filter="${esc(f.key)}"><option value="">${esc(f.label)}</option>${f.options
              .map((o) => `<option value="${esc(o)}" ${st.filters[f.key] === o ? "selected" : ""}>${esc(o)}</option>`)
              .join("")}</select>`,
        )
        .join("");

      return `
        <div class="card">
          <div class="table-tools">
            ${opts.search ? `<input class="search" type="search" placeholder="Search…" value="${esc(st.q)}" data-search />` : ""}
            ${filtersHtml}
            <div style="margin-left:auto;display:flex;gap:8px">
              ${opts.toolbar || ""}
              <button class="btn btn-secondary btn-sm" data-export>⬇ CSV</button>
            </div>
          </div>
          ${
            pageRows.length
              ? `<div class="table-wrap"><table>
                  <thead><tr>${opts.columns
                    .map(
                      (c) =>
                        `<th class="${c.sortable === false ? "" : "sortable"}" data-sort="${esc(c.key)}" ${c.width ? `style="width:${c.width}"` : ""}>${esc(
                          c.label,
                        )}${st.sort === c.key ? (st.dir === 1 ? " ▲" : " ▼") : ""}</th>`,
                    )
                    .join("")}</tr></thead>
                  <tbody>${pageRows
                    .map((r) => `<tr data-row="${esc(r.id)}">${opts.columns.map((c) => `<td>${c.render ? c.render(r) : esc(r[c.key] ?? "")}</td>`).join("")}</tr>`)
                    .join("")}</tbody>
                </table></div>
                <div class="pager">
                  <span>${rows.length} record${rows.length === 1 ? "" : "s"}</span>
                  <span class="spacer"></span>
                  <button class="btn btn-secondary btn-sm" data-page="prev" ${st.page === 1 ? "disabled" : ""}>Prev</button>
                  <span>Page ${st.page} of ${pages}</span>
                  <button class="btn btn-secondary btn-sm" data-page="next" ${st.page === pages ? "disabled" : ""}>Next</button>
                </div>`
              : `<div class="empty"><div class="big">📭</div><p>${esc(opts.empty || "Nothing here yet.")}</p></div>`
          }
        </div>`;
    };

    /** Wires events after the HTML is inserted into `container`. */
    const mount = (container, rerender) => {
      const redraw = () => rerender();
      container.querySelector("[data-search]")?.addEventListener("input", (e) => {
        st.q = e.target.value;
        st.page = 1;
        redraw();
        const s = container.querySelector("[data-search]");
        if (s) {
          s.focus();
          s.setSelectionRange(s.value.length, s.value.length);
        }
      });
      container.querySelectorAll("[data-filter]").forEach((sel) =>
        sel.addEventListener("change", (e) => {
          st.filters[e.target.dataset.filter] = e.target.value;
          st.page = 1;
          redraw();
        }),
      );
      container.querySelectorAll("th.sortable").forEach((th) =>
        th.addEventListener("click", () => {
          const k = th.dataset.sort;
          st.dir = st.sort === k ? -st.dir : 1;
          st.sort = k;
          redraw();
        }),
      );
      container.querySelectorAll("[data-page]").forEach((b) =>
        b.addEventListener("click", () => {
          st.page += b.dataset.page === "next" ? 1 : -1;
          redraw();
        }),
      );
      container.querySelector("[data-export]")?.addEventListener("click", () => exportCsv(opts.id, opts.rows, opts.columns));
    };

    return { render, mount, state: st };
  }

  function exportCsv(name, rows, columns) {
    const keys = columns.filter((c) => c.key !== "actions").map((c) => c.key);
    const head = columns.filter((c) => c.key !== "actions").map((c) => c.label);
    const lines = [head.join(",")].concat(
      rows.map((r) => keys.map((k) => `"${String(r[k] ?? "").replace(/"/g, '""')}"`).join(",")),
    );
    const blob = new Blob([lines.join("\n")], { type: "text/csv;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `${name}-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(a.href);
    toast("CSV downloaded");
  }

  const rowBtns = (id, extra = "") =>
    `<div class="row-actions">${extra}
      <button class="btn btn-secondary btn-sm" data-edit="${esc(id)}">Edit</button>
      <button class="btn btn-ghost btn-sm" data-del="${esc(id)}" title="Delete">🗑</button>
    </div>`;

  return { esc, fmtDate, fmtDateTime, fmtSize, initials, badge, toast, modal, closeModal, confirmDialog, formModal, formHtml, table, exportCsv, rowBtns };
})();
