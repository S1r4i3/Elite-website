/* Elite B Tax Services — Admin Panel
   Sidebar navigation, hash router, time-zone clocks and the demo login. */

(() => {
  const NAV = [
    {
      group: "Overview",
      items: [{ route: "dashboard", label: "Dashboard", icon: "🏠" }],
    },
    {
      group: "Clients",
      items: [
        { route: "clients", label: "All Clients", icon: "👥", count: () => DB.all("clients").length },
        { route: "documents", label: "Client Documents", icon: "📄", count: () => DB.all("documents").filter((d) => d.kind === "upload").length },
        { route: "drafts", label: "Draft Estimations", icon: "🧮", count: () => DB.all("documents").filter((d) => d.kind === "draft" && d.status === "awaiting_review").length },
        { route: "finals", label: "Final Documents", icon: "✅", count: () => DB.all("documents").filter((d) => d.kind === "final").length },
      ],
    },
    {
      group: "Enquiries",
      items: [
        { route: "leads", label: "Leads", icon: "📥", count: () => DB.all("leads").filter((l) => l.status === "new").length },
        { route: "inquiries", label: "Website Inquiries", icon: "💬", count: () => DB.all("inquiries").length },
      ],
    },
    {
      group: "Website content",
      items: [
        { route: "cmsPages", label: "Manage CMS Pages", icon: "📝" },
        { route: "banners", label: "Home Banners", icon: "🖼" },
        { route: "services", label: "Services & Pricing", icon: "🏷" },
        { route: "taxNotes", label: "Tax Notes", icon: "📌" },
      ],
    },
    {
      group: "Administration",
      items: [
        { route: "employees", label: "Employees", icon: "🧑‍💼" },
        { route: "logs", label: "Admin Logs", icon: "🔔" },
        { route: "settings", label: "Settings", icon: "⚙️" },
      ],
    },
  ];

  const $ = (sel) => document.querySelector(sel);
  const view = $("#view");
  const sidebar = $("#sidebar");

  /* ── Auth (demo, browser-only) ─────────────────────── */
  const SESSION_KEY = "ebt-admin-session";
  const isLoggedIn = () => sessionStorage.getItem(SESSION_KEY) === "1";

  function showLogin() {
    $("#login").hidden = false;
    $("#app").hidden = true;
    setTimeout(() => $("#pw").focus(), 50);
  }
  function showApp() {
    $("#login").hidden = true;
    $("#app").hidden = false;
    renderNav();
    route();
  }

  $("#login-form").addEventListener("submit", (e) => {
    e.preventDefault();
    if ($("#pw").value === DB.state.settings.password) {
      sessionStorage.setItem(SESSION_KEY, "1");
      DB.log("Signed in");
      $("#login-error").hidden = true;
      $("#pw").value = "";
      showApp();
    } else {
      $("#login-error").hidden = false;
    }
  });

  $("#logout").addEventListener("click", () => {
    sessionStorage.removeItem(SESSION_KEY);
    DB.log("Signed out");
    showLogin();
  });

  /* ── Sidebar ───────────────────────────────────────── */
  function renderNav() {
    const current = location.hash.replace("#/", "") || "dashboard";
    $("#nav").innerHTML = NAV.map(
      (g) => `
        <div class="nav-group">
          <p class="nav-group-title">${UI.esc(g.group)}</p>
          ${g.items
            .map((it) => {
              const n = it.count ? it.count() : 0;
              return `<a href="#/${it.route}" class="${current === it.route ? "active" : ""}">
                  <span class="ico">${it.icon}</span>${UI.esc(it.label)}
                  ${n ? `<span class="count">${n}</span>` : ""}
                </a>`;
            })
            .join("")}
        </div>`,
    ).join("");
    $("#admin-email").textContent = DB.state.settings.adminEmail;
    $("#tax-year-pill").textContent = `Taxation Year ${DB.state.settings.taxYear}`;
  }

  const closeSidebar = () => sidebar.classList.remove("open");
  $("#menu-btn").addEventListener("click", () => sidebar.classList.add("open"));
  $("#sidebar-close").addEventListener("click", closeSidebar);
  $("#nav").addEventListener("click", (e) => e.target.closest("a") && closeSidebar());

  /* ── Router ────────────────────────────────────────── */
  function route() {
    if (!isLoggedIn()) return showLogin();
    const name = location.hash.replace("#/", "") || "dashboard";
    const page = PAGES[name] || PAGES.dashboard;
    page.render(view, () => {
      page.render(view, () => route());
      renderNav();
    });
    renderNav();
    view.focus({ preventScroll: true });
    window.scrollTo({ top: 0 });
  }
  window.addEventListener("hashchange", route);

  /* ── Time-zone clocks (like the reference panel) ───── */
  const ZONES = [
    ["EST", "America/New_York"],
    ["CST", "America/Chicago"],
    ["MST", "America/Denver"],
    ["PST", "America/Los_Angeles"],
    ["AKST", "America/Anchorage"],
    ["India", "Asia/Kolkata"],
  ];
  function tickClocks() {
    const now = new Date();
    $("#clocks").innerHTML = ZONES.map(([label, tz]) => {
      const t = now.toLocaleString("en-US", { timeZone: tz, month: "numeric", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit", second: "2-digit" });
      return `<span><b>${label}</b> ${UI.esc(t)}</span>`;
    }).join("");
  }
  setInterval(tickClocks, 1000);
  tickClocks();

  /* ── Boot ──────────────────────────────────────────── */
  $("#year").textContent = new Date().getFullYear();
  if (!location.hash) location.hash = "#/dashboard";
  isLoggedIn() ? showApp() : showLogin();
})();
