/* Elite B Tax Services — Admin Panel
   One render function per sidebar page. Each returns HTML and gets a mount(container) call. */

const PAGES = (() => {
  const { esc, fmtDate, fmtDateTime, fmtSize, badge, toast, formModal, confirmDialog, table, rowBtns, initials } = UI;

  /* ── helpers ──────────────────────────────────────── */
  const head = (title, sub, actions = "") => `
    <div class="page-head">
      <div><h1>${esc(title)}</h1>${sub ? `<p>${esc(sub)}</p>` : ""}</div>
      ${actions ? `<div class="actions">${actions}</div>` : ""}
    </div>`;

  const clientOptions = () => DB.all("clients").map((c) => ({ value: c.id, label: `${c.firstName} ${c.lastName} (${c.clientId})` }));
  const yearOptions = () => {
    const y = new Date().getFullYear();
    return [y, y - 1, y - 2, y - 3, y - 4].map(String);
  };

  /** Standard "table page": rows + columns + add/edit form. */
  function crudPage({ id, title, sub, coll, columns, search, filters, fields, addLabel, empty, onRow, toolbar, rowsFn }) {
    return {
      render(container, rerender) {
        const rows = rowsFn ? rowsFn() : DB.all(coll);
        const t = table({ id, rows, columns, search, filters, empty, toolbar });
        container.innerHTML = head(title, sub, addLabel ? `<button class="btn btn-primary" data-add>+ ${esc(addLabel)}</button>` : "") + t.render();
        t.mount(container, rerender);

        container.querySelector("[data-add]")?.addEventListener("click", () =>
          formModal({
            title: addLabel,
            fields: fields(),
            submitLabel: "Create",
            onSubmit: (data, close) => {
              const row = DB.insert(coll, data);
              DB.log("Created " + title.toLowerCase().replace(/s$/, ""), row.name || row.title || `${row.firstName || ""} ${row.lastName || ""}`.trim());
              close();
              toast("Saved");
              rerender();
            },
          }),
        );
        container.querySelectorAll("[data-edit]").forEach((b) =>
          b.addEventListener("click", () => {
            const row = DB.find(coll, b.dataset.edit);
            formModal({
              title: "Edit",
              fields: fields(row),
              onSubmit: (data, close) => {
                DB.update(coll, row.id, data);
                DB.log("Updated " + title.toLowerCase().replace(/s$/, ""), data.name || data.title || `${data.firstName || ""} ${data.lastName || ""}`.trim());
                close();
                toast("Saved");
                rerender();
              },
            });
          }),
        );
        container.querySelectorAll("[data-del]").forEach((b) =>
          b.addEventListener("click", () =>
            confirmDialog("Delete this record? This can't be undone.", () => {
              DB.remove(coll, b.dataset.del);
              DB.log("Deleted from " + title.toLowerCase());
              toast("Deleted");
              rerender();
            }),
          ),
        );
        onRow && onRow(container, rerender);
      },
    };
  }

  /* ── Dashboard ────────────────────────────────────── */
  const dashboard = {
    render(container, rerender) {
      const s = DB.state;
      const docs = s.documents.filter((d) => d.kind === "upload");
      const drafts = s.documents.filter((d) => d.kind === "draft");
      const finals = s.documents.filter((d) => d.kind === "final");
      const pending = drafts.filter((d) => d.status === "awaiting_review").length;

      // uploads over the last 6 months
      const months = [];
      for (let i = 5; i >= 0; i--) {
        const d = new Date();
        d.setMonth(d.getMonth() - i, 1);
        months.push({ label: d.toLocaleString(undefined, { month: "short" }), key: `${d.getFullYear()}-${d.getMonth()}`, n: 0 });
      }
      s.documents.forEach((doc) => {
        const d = new Date(doc.createdAt);
        const m = months.find((x) => x.key === `${d.getFullYear()}-${d.getMonth()}`);
        if (m) m.n++;
      });
      const max = Math.max(1, ...months.map((m) => m.n));

      const stat = (ico, n, label, href) =>
        `<a class="card stat" href="${href}"><span class="ico">${ico}</span><span><b>${n}</b><span>${esc(label)}</span></span></a>`;

      container.innerHTML =
        head(`Welcome back 👋`, `${s.settings.companyName} — taxation year ${s.settings.taxYear}`) +
        `<div class="grid grid-4">
          ${stat("👥", s.clients.length, "Total clients", "#/clients")}
          ${stat("📄", docs.length, "Client documents", "#/documents")}
          ${stat("🧮", pending, "Drafts awaiting review", "#/drafts")}
          ${stat("✅", finals.length, "Final documents", "#/finals")}
        </div>

        <div class="grid grid-2" style="margin-top:16px">
          <div class="card">
            <div class="card-head"><h2>Documents received</h2><span class="muted" style="margin-left:auto;font-size:13px">last 6 months</span></div>
            <div class="chart">
              ${months.map((m) => `<span class="bar"><b>${m.n}</b><i style="height:${Math.round((m.n / max) * 100)}%"></i></span>`).join("")}
            </div>
            <div class="chart-labels">${months.map((m) => `<span>${esc(m.label)}</span>`).join("")}</div>
          </div>

          <div class="card">
            <div class="card-head"><h2>Recent website inquiries</h2><a href="#/inquiries" style="margin-left:auto;font-size:13px">View all</a></div>
            <div class="card-pad" style="padding-top:4px">
              ${
                s.inquiries.length
                  ? s.inquiries
                      .slice(0, 5)
                      .map(
                        (i) => `<div class="list-row">
                          <span class="avatar" style="width:34px;height:34px;font-size:12px">${esc(initials(i.name))}</span>
                          <span class="grow"><strong>${esc(i.name)}</strong><small>${esc(i.phone)} · ${esc(i.message || "No message")}</small></span>
                          <small class="subtle">${esc(fmtDate(i.createdAt))}</small>
                        </div>`,
                      )
                      .join("")
                  : `<p class="muted">No inquiries yet.</p>`
              }
            </div>
          </div>
        </div>

        <div class="grid grid-2" style="margin-top:16px">
          <div class="card">
            <div class="card-head"><h2>Newest clients</h2><a href="#/clients" style="margin-left:auto;font-size:13px">View all</a></div>
            <div class="table-wrap"><table>
              <thead><tr><th>Client ID</th><th>Name</th><th>Service</th><th>Status</th></tr></thead>
              <tbody>${s.clients
                .slice()
                .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
                .slice(0, 6)
                .map(
                  (c) =>
                    `<tr><td class="mono">${esc(c.clientId)}</td><td>${esc(c.firstName)} ${esc(c.lastName)}</td><td>${esc(c.service)}</td><td>${badge(c.status)}</td></tr>`,
                )
                .join("")}</tbody>
            </table></div>
          </div>

          <div class="card">
            <div class="card-head"><h2>Activity log</h2><a href="#/logs" style="margin-left:auto;font-size:13px">View all</a></div>
            <div class="card-pad" style="padding-top:4px">
              ${s.logs
                .slice(0, 6)
                .map(
                  (g) => `<div class="list-row">
                    <span class="grow"><strong>${esc(g.action)}</strong><small>${esc(g.who)}${g.detail ? " · " + esc(g.detail) : ""}</small></span>
                    <small class="subtle">${esc(fmtDateTime(g.createdAt))}</small>
                  </div>`,
                )
                .join("")}
            </div>
          </div>
        </div>`;
    },
  };

  /* ── Clients ──────────────────────────────────────── */
  const clientFields = (c = {}) => [
    { name: "firstName", label: "First name", value: c.firstName, required: true, full: false },
    { name: "lastName", label: "Last name", value: c.lastName, required: true, full: false },
    { name: "email", label: "Email", type: "email", value: c.email, required: true, full: false },
    { name: "phone", label: "Phone", type: "tel", value: c.phone, required: true, full: false },
    { name: "dob", label: "Date of birth", type: "date", value: c.dob, full: false },
    { name: "service", label: "Service", type: "select", value: c.service, options: DB.SERVICES, full: false },
    { name: "state", label: "State", value: c.state, full: false },
    { name: "country", label: "Country", value: c.country || "United States", full: false },
    { name: "taxYear", label: "Tax year", type: "select", value: c.taxYear, options: yearOptions(), full: false },
    { name: "status", label: "Status", type: "select", value: c.status || "active", options: ["active", "pending", "inactive"], full: false },
    { name: "address", label: "Address", value: c.address },
  ];

  const clients = {
    render(container, rerender) {
      const rows = DB.all("clients").map((c) => ({
        ...c,
        name: `${c.firstName} ${c.lastName}`,
        docs: DB.docsOf(c.id, "upload").length,
        drafts: DB.docsOf(c.id, "draft").length,
      }));
      const t = table({
        id: "clients",
        rows,
        search: ["name", "email", "phone", "clientId", "service"],
        filters: [
          { key: "status", label: "All statuses", options: ["active", "pending", "inactive"] },
          { key: "service", label: "All services", options: DB.SERVICES },
        ],
        empty: "No clients yet — add your first client.",
        columns: [
          { key: "clientId", label: "Client ID", render: (r) => `<span class="mono">${esc(r.clientId)}</span>` },
          {
            key: "name",
            label: "Client",
            render: (r) => `<strong>${esc(r.name)}</strong><br><small class="subtle">${esc(r.email)}</small>`,
          },
          { key: "phone", label: "Phone" },
          { key: "service", label: "Service" },
          { key: "docs", label: "Docs", render: (r) => `${r.docs} / ${r.drafts} drafts` },
          { key: "status", label: "Status", render: (r) => badge(r.status) },
          { key: "createdAt", label: "Joined", render: (r) => esc(fmtDate(r.createdAt)) },
          {
            key: "actions",
            label: "",
            sortable: false,
            render: (r) => rowBtns(r.id, `<button class="btn btn-secondary btn-sm" data-view="${esc(r.id)}">View</button>`),
          },
        ],
      });

      container.innerHTML =
        head("All Clients", `${rows.length} registered client accounts`, `<button class="btn btn-primary" data-add>+ Add client</button>`) + t.render();
      t.mount(container, rerender);

      container.querySelector("[data-add]").onclick = () =>
        formModal({
          title: "Add client",
          wide: true,
          fields: clientFields(),
          submitLabel: "Create client",
          onSubmit: (data, close) => {
            const row = DB.insert("clients", { ...data, clientId: DB.nextClientId(), lastLoginAt: null });
            DB.log("Added client", `${row.firstName} ${row.lastName} (${row.clientId})`);
            close();
            toast(`Client created — ${row.clientId}`);
            rerender();
          },
        });

      container.querySelectorAll("[data-edit]").forEach((b) => {
        b.onclick = () => {
          const c = DB.find("clients", b.dataset.edit);
          formModal({
            title: `Edit ${c.firstName} ${c.lastName}`,
            wide: true,
            fields: clientFields(c),
            onSubmit: (data, close) => {
              DB.update("clients", c.id, data);
              DB.log("Updated client", c.clientId);
              close();
              toast("Saved");
              rerender();
            },
          });
        };
      });
      container.querySelectorAll("[data-del]").forEach((b) => {
        b.onclick = () =>
          confirmDialog("Delete this client and all of their documents?", () => {
            DB.state.documents = DB.state.documents.filter((d) => d.clientId !== b.dataset.del);
            DB.remove("clients", b.dataset.del);
            DB.log("Deleted client");
            toast("Client deleted");
            rerender();
          });
      });
      container.querySelectorAll("[data-view]").forEach((b) => {
        b.onclick = () => clientProfile(b.dataset.view, rerender);
      });
    },
  };

  function clientProfile(id, rerender) {
    const c = DB.find("clients", id);
    if (!c) return;
    const group = (kind, title) => {
      const list = DB.docsOf(c.id, kind);
      return `<p class="section-title">${esc(title)} (${list.length})</p>
        ${
          list.length
            ? list
                .map(
                  (d) => `<div class="list-row">
                    <span class="grow"><strong>${esc(d.name)}</strong><small>${esc(d.type)} · ${esc(fmtSize(d.sizeKb))} · ${esc(fmtDate(d.createdAt))}${
                      d.note ? " · " + esc(d.note) : ""
                    }</small></span>
                    ${d.status ? badge(d.status) : ""}
                  </div>`,
                )
                .join("")
            : `<p class="muted" style="margin:0">None yet.</p>`
        }`;
    };
    UI.modal({
      title: `${c.firstName} ${c.lastName}`,
      wide: true,
      body: `
        <div style="display:flex;align-items:center;gap:14px;margin-bottom:16px">
          <span class="avatar" style="width:52px;height:52px;font-size:17px">${esc(initials(c.firstName + " " + c.lastName))}</span>
          <div>
            <strong class="mono" style="font-size:15px">${esc(c.clientId)}</strong>
            <div class="muted" style="font-size:13px">${esc(c.email)} · ${esc(c.phone)}</div>
          </div>
          <div style="margin-left:auto">${badge(c.status)}</div>
        </div>
        <dl class="kv">
          <div><dt>Service</dt><dd>${esc(c.service)}</dd></div>
          <div><dt>Tax year</dt><dd>${esc(c.taxYear)}</dd></div>
          <div><dt>Date of birth</dt><dd>${esc(c.dob || "—")}</dd></div>
          <div><dt>State / Country</dt><dd>${esc(c.state || "—")}, ${esc(c.country || "—")}</dd></div>
          <div><dt>Address</dt><dd>${esc(c.address || "—")}</dd></div>
          <div><dt>Joined</dt><dd>${esc(fmtDate(c.createdAt))}</dd></div>
        </dl>
        ${group("upload", "Client uploads")}
        ${group("draft", "Draft estimations")}
        ${group("final", "Final documents")}`,
      footer: `<button class="btn btn-secondary" data-close>Close</button><button class="btn btn-primary" id="share-doc">Share document</button>`,
    }).el.querySelector("#share-doc").onclick = () => {
      UI.closeModal();
      shareDocument(c.id, rerender);
    };
  }

  /** Upload a draft estimation or final document for a client. */
  function shareDocument(clientId, rerender, kind = "draft") {
    formModal({
      title: "Share document with client",
      fields: [
        { name: "clientId", label: "Client", type: "select", value: clientId, options: clientOptions() },
        { name: "kind", label: "Type", type: "select", value: kind, options: [
            { value: "draft", label: "Draft estimation (client reviews & approves)" },
            { value: "final", label: "Final document" },
            { value: "upload", label: "Client upload (on their behalf)" },
          ] },
        { name: "taxYear", label: "Tax year", type: "select", options: yearOptions(), full: false },
        { name: "type", label: "Document label", value: "Draft estimation", full: false },
        { name: "file", label: "File", type: "file" },
        { name: "note", label: "Note to client", type: "textarea", placeholder: "e.g. Estimated federal refund $2,140. Please confirm your dependents." },
      ],
      submitLabel: "Upload & share",
      onSubmit: (data, close) => {
        if (!data.file) return toast("Choose a file first", "error");
        DB.insert("documents", {
          clientId: data.clientId,
          kind: data.kind,
          name: data.file,
          type: data.type || (data.kind === "final" ? "Final return" : "Draft estimation"),
          taxYear: data.taxYear,
          sizeKb: data.fileSizeKb || 200,
          note: data.note,
          status: data.kind === "draft" ? "awaiting_review" : "",
          uploadedBy: data.kind === "upload" ? "client" : "staff",
        });
        DB.log("Shared " + data.kind, DB.clientName(data.clientId) + " — " + data.file);
        close();
        toast("Shared with client");
        rerender();
      },
    });
  }

  /* ── Documents / drafts / finals ──────────────────── */
  function docPage({ id, title, sub, kind, empty }) {
    return {
      render(container, rerender) {
        const rows = DB.all("documents")
          .filter((d) => d.kind === kind)
          .map((d) => ({ ...d, client: DB.clientName(d.clientId) }));
        const t = table({
          id,
          rows,
          search: ["name", "client", "type", "note"],
          filters: [{ key: "taxYear", label: "All tax years", options: yearOptions() }],
          empty,
          columns: [
            { key: "name", label: "File", render: (r) => `<strong>${esc(r.name)}</strong><br><small class="subtle">${esc(r.type)}${r.note ? " · " + esc(r.note) : ""}</small>` },
            { key: "client", label: "Client" },
            { key: "taxYear", label: "Tax year" },
            { key: "sizeKb", label: "Size", render: (r) => esc(fmtSize(r.sizeKb)) },
            ...(kind === "draft" ? [{ key: "status", label: "Status", render: (r) => badge(r.status) + (r.clientComment ? `<br><small class="subtle">${esc(r.clientComment)}</small>` : "") }] : []),
            { key: "createdAt", label: kind === "upload" ? "Received" : "Shared", render: (r) => esc(fmtDateTime(r.createdAt)) },
            {
              key: "actions",
              label: "",
              sortable: false,
              render: (r) => `<div class="row-actions">
                  <button class="btn btn-secondary btn-sm" data-dl="${esc(r.id)}">Download</button>
                  <button class="btn btn-ghost btn-sm" data-del="${esc(r.id)}" title="Delete">🗑</button>
                </div>`,
            },
          ],
        });

        container.innerHTML =
          head(title, sub, kind === "upload" ? "" : `<button class="btn btn-primary" data-share>+ Share ${kind === "draft" ? "draft estimation" : "final document"}</button>`) +
          t.render();
        t.mount(container, rerender);

        container.querySelector("[data-share]")?.addEventListener("click", () => shareDocument(DB.all("clients")[0]?.id, rerender, kind));
        container.querySelectorAll("[data-dl]").forEach((b) => {
          b.onclick = () => toast("Demo panel — file downloads need a real backend (see README).");
        });
        container.querySelectorAll("[data-del]").forEach((b) => {
          b.onclick = () =>
            confirmDialog("Delete this document?", () => {
              DB.remove("documents", b.dataset.del);
              DB.log("Deleted document");
              toast("Deleted");
              rerender();
            });
        });
      },
    };
  }

  /* ── Leads & inquiries ────────────────────────────── */
  const leads = crudPage({
    id: "leads",
    title: "Leads",
    sub: "Requests from the website contact and Get Started forms",
    coll: "leads",
    search: ["name", "email", "phone", "service"],
    filters: [{ key: "status", label: "All statuses", options: ["new", "contacted", "qualified", "converted", "closed"] }],
    empty: "No leads yet.",
    addLabel: "Add lead",
    columns: [
      { key: "name", label: "Name", render: (r) => `<strong>${esc(r.name)}</strong><br><small class="subtle">${esc(r.email)}</small>` },
      { key: "phone", label: "Phone" },
      { key: "service", label: "Service" },
      { key: "message", label: "Message", render: (r) => esc(r.message || "—") },
      { key: "status", label: "Status", render: (r) => badge(r.status) },
      { key: "createdAt", label: "Received", render: (r) => esc(fmtDate(r.createdAt)) },
      { key: "actions", label: "", sortable: false, render: (r) => rowBtns(r.id) },
    ],
    fields: (r = {}) => [
      { name: "name", label: "Name", value: r.name, required: true, full: false },
      { name: "email", label: "Email", type: "email", value: r.email, full: false },
      { name: "phone", label: "Phone", value: r.phone, full: false },
      { name: "service", label: "Service", type: "select", value: r.service, options: DB.SERVICES, full: false },
      { name: "status", label: "Status", type: "select", value: r.status || "new", options: ["new", "contacted", "qualified", "converted", "closed"], full: false },
      { name: "taxYear", label: "Tax year", type: "select", value: r.taxYear, options: yearOptions(), full: false },
      { name: "message", label: "Message", type: "textarea", value: r.message },
    ],
  });

  const inquiries = crudPage({
    id: "inquiries",
    title: "Website Inquiries",
    sub: "Messages from the pop-up form on the website",
    coll: "inquiries",
    search: ["name", "phone", "message"],
    empty: "No inquiries yet.",
    addLabel: "Add inquiry",
    columns: [
      { key: "name", label: "Name", render: (r) => `<strong>${esc(r.name)}</strong>` },
      { key: "phone", label: "Mobile", render: (r) => `<a href="tel:${esc(r.phone.replace(/[^\d+]/g, ""))}">${esc(r.phone)}</a>` },
      { key: "message", label: "Message", render: (r) => esc(r.message || "—") },
      { key: "page", label: "Page" },
      { key: "createdAt", label: "Received", render: (r) => esc(fmtDateTime(r.createdAt)) },
      { key: "actions", label: "", sortable: false, render: (r) => rowBtns(r.id) },
    ],
    fields: (r = {}) => [
      { name: "name", label: "Name", value: r.name, required: true, full: false },
      { name: "phone", label: "Mobile number", value: r.phone, required: true, full: false },
      { name: "page", label: "Page", value: r.page || "/", full: false },
      { name: "message", label: "Message", type: "textarea", value: r.message },
    ],
  });

  /* ── Content ──────────────────────────────────────── */
  const cmsPages = crudPage({
    id: "cms",
    title: "Manage CMS Pages",
    sub: "Editable page content",
    coll: "cmsPages",
    search: ["title", "slug"],
    empty: "No pages yet.",
    addLabel: "Add page",
    columns: [
      { key: "title", label: "Page name", render: (r) => `<strong>${esc(r.title)}</strong>` },
      { key: "slug", label: "URL", render: (r) => `<span class="mono">${esc(r.slug)}</span>` },
      { key: "body", label: "Content", render: (r) => esc((r.body || "").slice(0, 70) + ((r.body || "").length > 70 ? "…" : "")) },
      { key: "updatedAt", label: "Updated", render: (r) => esc(fmtDate(r.updatedAt || r.createdAt)) },
      { key: "actions", label: "", sortable: false, render: (r) => rowBtns(r.id) },
    ],
    fields: (r = {}) => [
      { name: "title", label: "Page name", value: r.title, required: true, full: false },
      { name: "slug", label: "URL path", value: r.slug || "/", required: true, full: false },
      { name: "body", label: "Content", type: "textarea", value: r.body },
    ],
  });

  const banners = crudPage({
    id: "banners",
    title: "Home Banners",
    sub: "Slides shown at the top of the homepage",
    coll: "banners",
    search: ["title", "subtitle"],
    empty: "No banners yet.",
    addLabel: "Add banner",
    columns: [
      { key: "title", label: "Title", render: (r) => `<strong>${esc(r.title)}</strong><br><small class="subtle">${esc(r.subtitle || "")}</small>` },
      { key: "cta", label: "Button" },
      { key: "link", label: "Link", render: (r) => `<span class="mono">${esc(r.link)}</span>` },
      { key: "active", label: "Shown", render: (r) => badge(String(r.active) === "true" || r.active === true ? "active" : "inactive") },
      { key: "actions", label: "", sortable: false, render: (r) => rowBtns(r.id) },
    ],
    fields: (r = {}) => [
      { name: "title", label: "Title", value: r.title, required: true },
      { name: "subtitle", label: "Subtitle", value: r.subtitle },
      { name: "cta", label: "Button label", value: r.cta, full: false },
      { name: "link", label: "Button link", value: r.link || "/get-started", full: false },
      { name: "active", label: "Shown on site", type: "select", value: String(r.active ?? true), options: ["true", "false"], full: false },
    ],
  });

  const services = crudPage({
    id: "services",
    title: "Manage Services & Pricing",
    sub: "Services listed on the website",
    coll: "services",
    search: ["name"],
    empty: "No services yet.",
    addLabel: "Add service",
    columns: [
      { key: "name", label: "Service", render: (r) => `<strong>${esc(r.name)}</strong>` },
      { key: "price", label: "Price (USD)", render: (r) => `$${esc(r.price)}` },
      { key: "active", label: "Shown", render: (r) => badge(String(r.active) === "true" || r.active === true ? "active" : "inactive") },
      { key: "updatedAt", label: "Updated", render: (r) => esc(fmtDate(r.updatedAt || r.createdAt)) },
      { key: "actions", label: "", sortable: false, render: (r) => rowBtns(r.id) },
    ],
    fields: (r = {}) => [
      { name: "name", label: "Service name", value: r.name, required: true },
      { name: "price", label: "Price (USD)", type: "number", value: r.price, full: false },
      { name: "active", label: "Shown on site", type: "select", value: String(r.active ?? true), options: ["true", "false"], full: false },
    ],
  });

  const taxNotes = crudPage({
    id: "notes",
    title: "Manage Tax Notes",
    sub: "Internal notes and reminders for the team",
    coll: "taxNotes",
    search: ["title", "body"],
    empty: "No notes yet.",
    addLabel: "Add note",
    columns: [
      { key: "title", label: "Title", render: (r) => `<strong>${esc(r.title)}</strong>` },
      { key: "body", label: "Note" },
      { key: "updatedAt", label: "Updated", render: (r) => esc(fmtDate(r.updatedAt || r.createdAt)) },
      { key: "actions", label: "", sortable: false, render: (r) => rowBtns(r.id) },
    ],
    fields: (r = {}) => [
      { name: "title", label: "Title", value: r.title, required: true },
      { name: "body", label: "Note", type: "textarea", value: r.body },
    ],
  });

  /* ── Team ─────────────────────────────────────────── */
  const employees = crudPage({
    id: "employees",
    title: "Employees",
    sub: "Staff who can access this panel",
    coll: "employees",
    search: ["name", "email", "role"],
    filters: [{ key: "role", label: "All roles", options: ["Super Admin", "Preparer", "Reviewer", "Support"] }],
    empty: "No employees yet.",
    addLabel: "Add employee",
    columns: [
      {
        key: "name",
        label: "Name",
        render: (r) => `<div style="display:flex;align-items:center;gap:10px"><span class="avatar" style="width:32px;height:32px;font-size:12px">${esc(
          initials(r.name),
        )}</span><span><strong>${esc(r.name)}</strong><br><small class="subtle">${esc(r.email)}</small></span></div>`,
      },
      { key: "role", label: "Role" },
      { key: "phone", label: "Phone" },
      { key: "status", label: "Status", render: (r) => badge(r.status) },
      { key: "createdAt", label: "Added", render: (r) => esc(fmtDate(r.createdAt)) },
      { key: "actions", label: "", sortable: false, render: (r) => rowBtns(r.id) },
    ],
    fields: (r = {}) => [
      { name: "name", label: "Full name", value: r.name, required: true, full: false },
      { name: "email", label: "Email", type: "email", value: r.email, required: true, full: false },
      { name: "phone", label: "Phone", value: r.phone, full: false },
      { name: "role", label: "Role", type: "select", value: r.role || "Preparer", options: ["Super Admin", "Preparer", "Reviewer", "Support"], full: false },
      { name: "status", label: "Status", type: "select", value: r.status || "active", options: ["active", "inactive"], full: false },
    ],
  });

  const logs = {
    render(container, rerender) {
      const t = table({
        id: "logs",
        rows: DB.all("logs"),
        search: ["who", "action", "detail"],
        empty: "No activity yet.",
        perPage: 15,
        columns: [
          { key: "action", label: "Action", render: (r) => `<strong>${esc(r.action)}</strong>` },
          { key: "detail", label: "Detail", render: (r) => esc(r.detail || "—") },
          { key: "who", label: "By" },
          { key: "createdAt", label: "When", render: (r) => esc(fmtDateTime(r.createdAt)) },
        ],
      });
      container.innerHTML = head("Admin Logs", "Everything done inside this panel") + t.render();
      t.mount(container, rerender);
    },
  };

  /* ── Settings ─────────────────────────────────────── */
  const settings = {
    render(container, rerender) {
      const s = DB.state.settings;
      container.innerHTML =
        head("Settings", "Company details shown on the website") +
        `<div class="grid grid-2">
          <form class="card card-pad" id="company-form">
            <h2 style="font-size:16px;margin-bottom:14px">Company & contact</h2>
            ${UI.formHtml([
              { name: "companyName", label: "Company name", value: s.companyName, full: false },
              { name: "taxYear", label: "Taxation year", type: "select", value: s.taxYear, options: yearOptions(), full: false },
              { name: "phoneUs", label: "U.S. phone", value: s.phoneUs, full: false },
              { name: "phoneIn", label: "India phone", value: s.phoneIn, full: false },
              { name: "whatsapp", label: "WhatsApp number", value: s.whatsapp, full: false },
              { name: "email", label: "Email", type: "email", value: s.email, full: false },
              { name: "address", label: "Address", value: s.address },
            ])}
            <button class="btn btn-primary" type="submit">Save company details</button>
          </form>

          <div style="display:flex;flex-direction:column;gap:16px">
            <form class="card card-pad" id="social-form">
              <h2 style="font-size:16px;margin-bottom:14px">Social links & SEO</h2>
              ${UI.formHtml([
                { name: "facebook", label: "Facebook", value: s.social.facebook, full: false },
                { name: "instagram", label: "Instagram", value: s.social.instagram, full: false },
                { name: "linkedin", label: "LinkedIn", value: s.social.linkedin, full: false },
                { name: "youtube", label: "YouTube", value: s.social.youtube, full: false },
                { name: "seoTitle", label: "SEO title", value: s.seoTitle },
                { name: "seoDescription", label: "SEO description", type: "textarea", value: s.seoDescription },
              ])}
              <button class="btn btn-primary" type="submit">Save</button>
            </form>

            <form class="card card-pad" id="pw-form">
              <h2 style="font-size:16px;margin-bottom:14px">Change password</h2>
              ${UI.formHtml([
                { name: "current", label: "Current password", type: "password", required: true },
                { name: "next", label: "New password", type: "password", required: true, hint: "At least 6 characters." },
              ])}
              <button class="btn btn-secondary" type="submit">Update password</button>
            </form>

            <div class="card card-pad">
              <h2 style="font-size:16px;margin-bottom:8px">Demo data</h2>
              <p class="muted" style="margin:0 0 12px;font-size:14px">Reset the panel back to the sample clients and documents it shipped with.</p>
              <button class="btn btn-secondary" id="reset-db">Reset demo data</button>
            </div>
          </div>
        </div>`;

      const vals = (form) => Object.fromEntries(new FormData(form).entries());

      container.querySelector("#company-form").onsubmit = (e) => {
        e.preventDefault();
        Object.assign(DB.state.settings, vals(e.target));
        DB.save();
        DB.log("Updated company settings");
        toast("Company details saved");
        rerender();
      };
      container.querySelector("#social-form").onsubmit = (e) => {
        e.preventDefault();
        const v = vals(e.target);
        DB.state.settings.social = { facebook: v.facebook, instagram: v.instagram, linkedin: v.linkedin, youtube: v.youtube };
        DB.state.settings.seoTitle = v.seoTitle;
        DB.state.settings.seoDescription = v.seoDescription;
        DB.save();
        DB.log("Updated social & SEO settings");
        toast("Saved");
      };
      container.querySelector("#pw-form").onsubmit = (e) => {
        e.preventDefault();
        const v = vals(e.target);
        if (v.current !== DB.state.settings.password) return toast("Current password is incorrect", "error");
        if ((v.next || "").length < 6) return toast("New password must be at least 6 characters", "error");
        DB.state.settings.password = v.next;
        DB.save();
        DB.log("Changed admin password");
        e.target.reset();
        toast("Password updated");
      };
      container.querySelector("#reset-db").onclick = () =>
        confirmDialog("Reset all demo data? Anything you changed in this panel will be lost.", () => {
          DB.reset();
          toast("Demo data reset");
          rerender();
        });
    },
  };

  return {
    dashboard,
    clients,
    documents: docPage({ id: "docs", title: "Client Documents", sub: "Files uploaded by clients", kind: "upload", empty: "No client uploads yet." }),
    drafts: docPage({ id: "drafts", title: "Draft Estimations", sub: "Drafts shared with clients for review", kind: "draft", empty: "No drafts shared yet." }),
    finals: docPage({ id: "finals", title: "Final Documents", sub: "Completed returns shared with clients", kind: "final", empty: "No final documents yet." }),
    leads,
    inquiries,
    cmsPages,
    banners,
    services,
    taxNotes,
    employees,
    logs,
    settings,
  };
})();
