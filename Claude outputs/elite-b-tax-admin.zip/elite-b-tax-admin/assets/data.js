/* Elite B Tax Services — Admin Panel
   Local data store. Everything is kept in the browser (localStorage) so the panel
   runs with no server or database. See README.md → "Connecting to a real backend". */

const DB = (() => {
  const KEY = "ebt-admin-db-v1";

  const iso = (daysAgo, hour = 10) => {
    const d = new Date();
    d.setDate(d.getDate() - daysAgo);
    d.setHours(hour, (daysAgo * 7) % 60, 0, 0);
    return d.toISOString();
  };
  const YEAR = new Date().getFullYear();
  const cid = (n) => `EBT-${YEAR}-${String(n).padStart(4, "0")}`;

  const SERVICES = [
    "Federal Tax Filing",
    "State Tax Filing",
    "FBAR / FATCA",
    "ITIN Services",
    "Tax Amendments",
    "IRS Representation",
    "LLC Services",
    "Corporate Tax",
    "Bookkeeping",
    "Payroll",
    "Indian / NRI Tax",
  ];

  const seedClients = [
    ["Ravi", "Teja", "ravi.teja@example.com", "+1 302 555 0111", "Texas", "United States", "Federal Tax Filing", "active"],
    ["Priya", "Sharma", "priya.sharma@example.com", "+1 302 555 0112", "New Jersey", "United States", "FBAR / FATCA", "active"],
    ["Anil", "Kumar", "anil.kumar@example.com", "+91 98765 43210", "Telangana", "India", "Indian / NRI Tax", "active"],
    ["Meera", "Nair", "meera.nair@example.com", "+1 302 555 0114", "California", "United States", "ITIN Services", "pending"],
    ["John", "Miller", "john.miller@example.com", "+1 302 555 0115", "Delaware", "United States", "Corporate Tax", "active"],
    ["Sita", "Rao", "sita.rao@example.com", "+1 302 555 0116", "Illinois", "United States", "State Tax Filing", "active"],
    ["Arjun", "Patel", "arjun.patel@example.com", "+1 302 555 0117", "New York", "United States", "LLC Services", "pending"],
    ["Grace", "Chen", "grace.chen@example.com", "+1 302 555 0118", "Washington", "United States", "Bookkeeping", "active"],
    ["Kiran", "Das", "kiran.das@example.com", "+91 90000 12345", "Karnataka", "India", "Indian / NRI Tax", "inactive"],
    ["Daniel", "Brown", "daniel.brown@example.com", "+1 302 555 0120", "Florida", "United States", "Tax Amendments", "active"],
    ["Asha", "Reddy", "asha.reddy@example.com", "+1 302 555 0121", "Texas", "United States", "Payroll", "active"],
    ["Mark", "Wilson", "mark.wilson@example.com", "+1 302 555 0122", "Ohio", "United States", "IRS Representation", "pending"],
  ];

  function seed() {
    const clients = seedClients.map(([firstName, lastName, email, phone, state, country, service, status], i) => ({
      id: "c" + (i + 1),
      clientId: cid(i + 1),
      firstName,
      lastName,
      email,
      phone,
      state,
      country,
      service,
      status,
      taxYear: String(YEAR - 1),
      dob: `19${70 + (i % 25)}-0${(i % 9) + 1}-1${i % 9}`,
      address: `${10 + i} Main Street`,
      createdAt: iso(60 - i * 3),
      lastLoginAt: iso(i % 14),
    }));

    const docTypes = ["W-2", "1099-INT", "1099-NEC", "1098-T", "Prior-year return", "Passport / ID", "Bank statement"];
    const documents = [];
    let d = 1;
    clients.forEach((c, ci) => {
      const n = (ci % 4) + 1;
      for (let k = 0; k < n; k++) {
        documents.push({
          id: "d" + d++,
          clientId: c.id,
          kind: "upload",
          name: `${docTypes[(ci + k) % docTypes.length].replace(/[\/\s]/g, "-")}-${c.lastName}.pdf`,
          type: docTypes[(ci + k) % docTypes.length],
          taxYear: String(YEAR - 1),
          sizeKb: 120 + ((ci * 37 + k * 53) % 900),
          note: "",
          status: "",
          uploadedBy: "client",
          createdAt: iso(40 - ci * 2 - k),
        });
      }
    });

    const drafts = clients.slice(0, 6).map((c, i) => ({
      id: "dr" + (i + 1),
      clientId: c.id,
      kind: "draft",
      name: `Draft-Estimate-${YEAR - 1}-${c.lastName}.pdf`,
      type: "Draft estimation",
      taxYear: String(YEAR - 1),
      sizeKb: 220 + i * 30,
      note: ["Estimated federal refund $2,140. Please confirm dependents.", "Balance due $860 — review before filing.", "Refund $1,020 after education credit.", "Estimate includes FBAR reporting.", "Draft for review — state return pending.", "Refund $3,410. Confirm bank details."][i],
      status: ["awaiting_review", "approved", "changes_requested", "awaiting_review", "approved", "awaiting_review"][i],
      clientComment: i === 2 ? "I also have a 1099-INT from my savings account." : "",
      uploadedBy: "staff",
      createdAt: iso(18 - i * 2),
    }));

    const finals = clients.slice(0, 3).map((c, i) => ({
      id: "f" + (i + 1),
      clientId: c.id,
      kind: "final",
      name: `Form-1040-${YEAR - 1}-${c.lastName}.pdf`,
      type: "Final return",
      taxYear: String(YEAR - 1),
      sizeKb: 410 + i * 45,
      note: "Accepted by the IRS.",
      status: "",
      uploadedBy: "staff",
      createdAt: iso(8 - i * 2),
    }));

    return {
      settings: {
        password: "admin123",
        adminEmail: "admin@elitebtax.com",
        companyName: "Elite B Tax Services",
        taxYear: String(YEAR),
        phoneUs: "+1 (302) 202-2139",
        phoneIn: "+91 99127 62149",
        email: "support@elitebtax.com",
        whatsapp: "+91 99127 62149",
        address: "8 The Green, Ste A, Dover, Delaware 19901, US",
        social: { facebook: "", instagram: "", linkedin: "", youtube: "" },
        seoTitle: "Elite B Tax Services — U.S. & India Tax Filing",
        seoDescription: "Individual, business and U.S. + India tax services — prepared by professionals and explained in plain language.",
      },
      clients,
      documents: [...documents, ...drafts, ...finals],
      inquiries: [
        { id: "i1", name: "Rahul Verma", phone: "+91 99887 76655", message: "Need help filing ITR for FY 2024-25.", page: "/", createdAt: iso(1, 9) },
        { id: "i2", name: "Laura Smith", phone: "+1 302 555 0180", message: "Do you handle multi-state returns?", page: "/tax-services", createdAt: iso(2, 14) },
        { id: "i3", name: "Suresh Babu", phone: "+91 91234 56780", message: "FBAR filing for 3 foreign accounts.", page: "/fbar", createdAt: iso(4, 11) },
        { id: "i4", name: "Emily Davis", phone: "+1 302 555 0182", message: "", page: "/", createdAt: iso(6, 16) },
      ],
      leads: [
        { id: "l1", name: "Vikram Singh", email: "vikram@example.com", phone: "+1 302 555 0190", service: "Corporate Tax", taxYear: String(YEAR - 1), message: "S-corp return + bookkeeping.", status: "new", createdAt: iso(1, 10) },
        { id: "l2", name: "Nisha Gupta", email: "nisha@example.com", phone: "+1 302 555 0191", service: "ITIN Services", taxYear: String(YEAR - 1), message: "ITIN for spouse and child.", status: "contacted", createdAt: iso(3, 12) },
        { id: "l3", name: "Peter Adams", email: "peter@example.com", phone: "+1 302 555 0192", service: "Federal Tax Filing", taxYear: String(YEAR - 1), message: "", status: "qualified", createdAt: iso(5, 15) },
        { id: "l4", name: "Divya Menon", email: "divya@example.com", phone: "+91 99000 11223", service: "Indian / NRI Tax", taxYear: String(YEAR - 1), message: "US + India filing this year.", status: "converted", createdAt: iso(9, 13) },
      ],
      employees: [
        { id: "e1", name: "Sriram K.", email: "sriram@elitebtax.com", role: "Super Admin", phone: "+1 302 202 2139", status: "active", createdAt: iso(300) },
        { id: "e2", name: "Deepa M.", email: "deepa@elitebtax.com", role: "Preparer", phone: "+91 90000 22334", status: "active", createdAt: iso(120) },
        { id: "e3", name: "Alex Turner", email: "alex@elitebtax.com", role: "Reviewer", phone: "+1 302 555 0170", status: "active", createdAt: iso(80) },
        { id: "e4", name: "Nikhil R.", email: "nikhil@elitebtax.com", role: "Support", phone: "+91 90000 55667", status: "inactive", createdAt: iso(45) },
      ],
      cmsPages: [
        { id: "p1", title: "Welcome to Elite B Tax", slug: "/", body: "Your taxes. Done right. Without the stress.", updatedAt: iso(3) },
        { id: "p2", title: "Federal Refund Status", slug: "/refund-status/federal", body: "Check your federal refund with the IRS Where's My Refund tool.", updatedAt: iso(9) },
        { id: "p3", title: "State Refund Status", slug: "/refund-status/state", body: "Links to each state's refund tracker.", updatedAt: iso(9) },
        { id: "p4", title: "Pay Federal Taxes Online", slug: "/pay/federal", body: "Pay through IRS Direct Pay or EFTPS.", updatedAt: iso(20) },
        { id: "p5", title: "Pay State Taxes Online", slug: "/pay/state", body: "State payment portals by state.", updatedAt: iso(20) },
        { id: "p6", title: "Client Tax Questionnaire", slug: "/questionnaire", body: "Questions we ask before preparing your return.", updatedAt: iso(31) },
        { id: "p7", title: "About Us", slug: "/about", body: "Accessible, approachable and accountable tax help.", updatedAt: iso(44) },
      ],
      banners: [
        { id: "b1", title: "Your Taxes. Done Right.", subtitle: "Professional tax preparation without the stress.", cta: "Get Started", link: "/get-started", active: true, updatedAt: iso(5) },
        { id: "b2", title: "U.S. + India Tax Under One Roof", subtitle: "One team for both countries.", cta: "Indian Tax Services", link: "/indian-tax-services", active: true, updatedAt: iso(15) },
        { id: "b3", title: "FBAR & FATCA Reporting", subtitle: "Foreign accounts reported correctly.", cta: "Learn More", link: "/fbar", active: false, updatedAt: iso(40) },
      ],
      services: SERVICES.map((name, i) => ({
        id: "s" + (i + 1),
        name,
        price: [149, 99, 199, 129, 179, 299, 349, 499, 249, 199, 229][i],
        active: true,
        updatedAt: iso(10 + i),
      })),
      taxNotes: [
        { id: "n1", title: "2025 standard deduction", body: "Single $15,000 / MFJ $30,000 (confirm with IRS Pub 501 before filing).", updatedAt: iso(12) },
        { id: "n2", title: "FBAR deadline", body: "April 15 with an automatic extension to October 15.", updatedAt: iso(25) },
        { id: "n3", title: "ITIN renewals", body: "ITINs not used on a return in the last 3 years expire.", updatedAt: iso(38) },
      ],
      logs: [
        { id: "g1", who: "admin@elitebtax.com", action: "Signed in", detail: "Chrome on Windows", createdAt: iso(0, 9) },
        { id: "g2", who: "deepa@elitebtax.com", action: "Uploaded draft estimate", detail: "Ravi Teja", createdAt: iso(1, 11) },
        { id: "g3", who: "admin@elitebtax.com", action: "Updated CMS page", detail: "Client Tax Questionnaire", createdAt: iso(2, 15) },
        { id: "g4", who: "alex@elitebtax.com", action: "Marked lead as qualified", detail: "Peter Adams", createdAt: iso(3, 17) },
      ],
    };
  }

  let state;
  try {
    const raw = localStorage.getItem(KEY);
    state = raw ? JSON.parse(raw) : seed();
  } catch {
    state = seed();
  }

  function save() {
    try {
      localStorage.setItem(KEY, JSON.stringify(state));
    } catch (e) {
      console.warn("Could not save to localStorage", e);
    }
  }

  const uid = (p) => p + Math.random().toString(36).slice(2, 9);

  return {
    get state() {
      return state;
    },
    save,
    reset() {
      state = seed();
      save();
    },
    /** All rows in a collection, newest first where relevant. */
    all(coll) {
      return state[coll] || [];
    },
    find(coll, id) {
      return (state[coll] || []).find((r) => r.id === id) || null;
    },
    insert(coll, row) {
      const rec = { id: uid(coll[0]), createdAt: new Date().toISOString(), ...row };
      state[coll].unshift(rec);
      save();
      return rec;
    },
    update(coll, id, patch) {
      const row = this.find(coll, id);
      if (!row) return null;
      Object.assign(row, patch, { updatedAt: new Date().toISOString() });
      save();
      return row;
    },
    remove(coll, id) {
      state[coll] = (state[coll] || []).filter((r) => r.id !== id);
      save();
    },
    log(action, detail) {
      state.logs.unshift({ id: uid("g"), who: state.settings.adminEmail, action, detail: detail || "", createdAt: new Date().toISOString() });
      state.logs = state.logs.slice(0, 500);
      save();
    },
    /** Next client ID, e.g. EBT-2026-0013 */
    nextClientId() {
      const prefix = `EBT-${state.settings.taxYear}-`;
      const max = state.clients.reduce((m, c) => (c.clientId?.startsWith(prefix) ? Math.max(m, parseInt(c.clientId.slice(prefix.length), 10) || 0) : m), 0);
      return prefix + String(max + 1).padStart(4, "0");
    },
    clientName(id) {
      const c = this.find("clients", id);
      return c ? `${c.firstName} ${c.lastName}` : "—";
    },
    docsOf(clientId, kind) {
      return state.documents.filter((d) => d.clientId === clientId && (!kind || d.kind === kind));
    },
    SERVICES,
  };
})();
