import "server-only";
import { promises as fs } from "node:fs";
import path from "node:path";

/** Private file storage on disk. Swap these two functions for S3/GCS in production. */
const root = () => path.resolve(process.cwd(), process.env.UPLOAD_DIR || "./data/uploads");

export async function saveFile(key: string, data: Buffer) {
  const file = path.join(root(), key);
  await fs.mkdir(path.dirname(file), { recursive: true });
  await fs.writeFile(file, data, { mode: 0o600 });
  return key;
}

export async function readFile(key: string) {
  const file = path.join(root(), key);
  if (!file.startsWith(root())) throw new Error("Invalid key");
  return fs.readFile(file);
}

export async function deleteFile(key: string) {
  if (!key) return;
  await fs.rm(path.join(root(), key), { force: true }).catch(() => {});
}
