import { redirect } from "next/navigation";
import { currentAdmin } from "@/lib/auth";
import { getSettings } from "@/lib/db";
import { Shell } from "@/components/shell";

/** Verifies the session, then renders the sidebar shell around a page. */
export async function AdminPage({ children }: { children: React.ReactNode }) {
  const admin = await currentAdmin();
  if (!admin) redirect("/login");
  const settings = await getSettings();
  return (
    <Shell admin={admin} taxYear={settings.taxYear}>
      {children}
    </Shell>
  );
}
