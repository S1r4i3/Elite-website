import Link from "next/link";
import { notFound } from "next/navigation";
import { AdminPage } from "../../admin-layout";
import { get, list } from "@/lib/db";
import { Badge } from "@/components/data-table";
import { ClientDocuments } from "@/components/client-documents";
import type { Client, DocumentRow } from "@/lib/types";

export const dynamic = "force-dynamic";

const fmtDate = (v?: string) => (v ? new Date(v).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" }) : "—");

export default async function ClientPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const client = await get<Client>("clients", id);
  if (!client) notFound();
  const docs = (await list<DocumentRow>("documents")).filter((d) => d.clientId === id);

  const facts: [string, string][] = [
    ["Client ID", client.clientId],
    ["Email", client.email],
    ["Phone", client.phone],
    ["Service", client.service],
    ["Tax year", client.taxYear],
    ["Date of birth", client.dob || "—"],
    ["State", client.state || "—"],
    ["Country", client.country || "—"],
    ["Address", client.address || "—"],
    ["Joined", fmtDate(client.createdAt)],
    ["Last login", fmtDate(client.lastLoginAt || undefined)],
  ];

  return (
    <AdminPage>
      <div className="page-head">
        <div>
          <p className="muted" style={{ marginBottom: 4 }}>
            <Link href="/clients">← All clients</Link>
          </p>
          <h1>
            {client.firstName} {client.lastName}
          </h1>
          <p>
            <span className="mono">{client.clientId}</span> · <Badge value={client.status} />
          </p>
        </div>
      </div>

      <div className="grid grid-2">
        <div className="card card-pad">
          <h2 style={{ fontSize: 16, marginBottom: 14 }}>Client details</h2>
          <dl className="kv">
            {facts.map(([k, v]) => (
              <div key={k}>
                <dt>{k}</dt>
                <dd>{v}</dd>
              </div>
            ))}
          </dl>
        </div>

        <div className="card card-pad">
          <h2 style={{ fontSize: 16, marginBottom: 6 }}>Summary</h2>
          <div className="grid grid-3" style={{ gap: 10 }}>
            {[
              ["Uploads", docs.filter((d) => d.kind === "upload").length],
              ["Drafts", docs.filter((d) => d.kind === "draft").length],
              ["Finals", docs.filter((d) => d.kind === "final").length],
            ].map(([label, n]) => (
              <div key={String(label)} style={{ background: "var(--canvas)", borderRadius: 12, padding: "12px 14px" }}>
                <b style={{ fontSize: 22, display: "block" }}>{n}</b>
                <span className="muted" style={{ fontSize: 13 }}>
                  {label}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-16">
        <ClientDocuments clientId={client.id} initial={docs} />
      </div>
    </AdminPage>
  );
}
