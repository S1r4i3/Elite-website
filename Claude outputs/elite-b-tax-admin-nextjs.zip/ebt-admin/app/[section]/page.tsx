import { notFound } from "next/navigation";
import { AdminPage } from "../admin-layout";
import { DataTable } from "@/components/data-table";
import { SECTIONS, sectionBySlug } from "@/lib/sections";

export const dynamic = "force-dynamic";

/** Every list page (clients, documents, drafts, leads, CMS…) is rendered from lib/sections.ts. */
export function generateStaticParams() {
  return SECTIONS.map((s) => ({ section: s.slug }));
}

export default async function SectionPage({ params }: { params: Promise<{ section: string }> }) {
  const section = sectionBySlug((await params).section);
  if (!section) notFound();
  return (
    <AdminPage>
      <DataTable section={section} />
    </AdminPage>
  );
}
