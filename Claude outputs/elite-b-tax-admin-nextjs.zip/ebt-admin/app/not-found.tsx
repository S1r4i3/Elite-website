import Link from "next/link";

export default function NotFound() {
  return (
    <div className="login">
      <div className="login-card">
        <div className="login-logo">
          <span className="mark">EBT</span>
        </div>
        <h1>Page not found</h1>
        <p className="muted">That page doesn&apos;t exist in the admin panel.</p>
        <Link className="btn btn-primary btn-block" href="/">
          Back to dashboard
        </Link>
      </div>
    </div>
  );
}
