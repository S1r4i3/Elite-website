import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/auth";
import { create, list, log, nextClientId } from "@/lib/db";
import type { Collection, Row } from "@/lib/types";

export const dynamic = "force-dynamic";

const ALLOWED: Collection[] = ["clients", "documents", "leads", "inquiries", "cmsPages", "banners", "services", "taxNotes", "employees", "logs"];
const isAllowed = (c: string): c is Collection => (ALLOWED as string[]).includes(c);

/**
 * GET  /api/{collection}?q=&limit=&kind=&status=
 * POST /api/{collection}
 *
 * Collections: clients, documents, leads, inquiries, cmsPages, banners,
 *              services, taxNotes, employees, logs
 */
export async function GET(req: Request, { params }: { params: Promise<{ collection: string }> }) {
  try {
    await requireAdmin();
  } catch (r) {
    return r as Response;
  }
  const { collection } = await params;
  if (!isAllowed(collection)) return NextResponse.json({ ok: false, error: "Unknown collection" }, { status: 404 });

  const url = new URL(req.url);
  let rows = await list<Row>(collection);

  // Simple server-side filters — extend as needed.
  for (const key of ["kind", "status", "clientId", "taxYear", "role"]) {
    const v = url.searchParams.get(key);
    if (v) rows = rows.filter((r) => String(r[key] ?? "") === v);
  }
  const q = url.searchParams.get("q")?.toLowerCase();
  if (q) rows = rows.filter((r) => JSON.stringify(r).toLowerCase().includes(q));
  const limit = Number(url.searchParams.get("limit") || 0);
  if (limit > 0) rows = rows.slice(0, limit);

  // Never send password hashes to the browser.
  if (collection === "employees") rows = rows.map(({ passwordHash: _ignored, ...rest }) => rest as Row);

  return NextResponse.json({ ok: true, rows, total: rows.length });
}

export async function POST(req: Request, { params }: { params: Promise<{ collection: string }> }) {
  let admin;
  try {
    admin = await requireAdmin();
  } catch (r) {
    return r as Response;
  }
  const { collection } = await params;
  if (!isAllowed(collection) || collection === "logs") return NextResponse.json({ ok: false, error: "Unknown collection" }, { status: 404 });

  const body = (await req.json().catch(() => null)) as Record<string, unknown> | null;
  if (!body) return NextResponse.json({ ok: false, error: "Invalid JSON body" }, { status: 400 });

  if (collection === "clients") {
    if (!body.firstName || !body.lastName || !body.email) {
      return NextResponse.json({ ok: false, error: "First name, last name and email are required." }, { status: 400 });
    }
    body.clientId = body.clientId || (await nextClientId());
  }

  const row = await create(collection, body);
  await log(admin.email, `Created ${collection.replace(/s$/, "")}`, String(body.name || body.title || body.clientId || ""));
  return NextResponse.json({ ok: true, row }, { status: 201 });
}
