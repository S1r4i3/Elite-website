import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/auth";
import { get, log, remove, update } from "@/lib/db";
import { deleteFile } from "@/lib/storage";
import type { Collection, DocumentRow, Row } from "@/lib/types";

export const dynamic = "force-dynamic";

const ALLOWED: Collection[] = ["clients", "documents", "leads", "inquiries", "cmsPages", "banners", "services", "taxNotes", "employees", "logs"];
const isAllowed = (c: string): c is Collection => (ALLOWED as string[]).includes(c);

/** GET / PATCH / DELETE  /api/{collection}/{id} */
export async function GET(_req: Request, { params }: { params: Promise<{ collection: string; id: string }> }) {
  try {
    await requireAdmin();
  } catch (r) {
    return r as Response;
  }
  const { collection, id } = await params;
  if (!isAllowed(collection)) return NextResponse.json({ ok: false, error: "Unknown collection" }, { status: 404 });
  const row = await get<Row>(collection, id);
  if (!row) return NextResponse.json({ ok: false, error: "Not found" }, { status: 404 });
  if (collection === "employees") delete (row as Record<string, unknown>).passwordHash;
  return NextResponse.json({ ok: true, row });
}

export async function PATCH(req: Request, { params }: { params: Promise<{ collection: string; id: string }> }) {
  let admin;
  try {
    admin = await requireAdmin();
  } catch (r) {
    return r as Response;
  }
  const { collection, id } = await params;
  if (!isAllowed(collection)) return NextResponse.json({ ok: false, error: "Unknown collection" }, { status: 404 });
  const patch = (await req.json().catch(() => null)) as Record<string, unknown> | null;
  if (!patch) return NextResponse.json({ ok: false, error: "Invalid JSON body" }, { status: 400 });
  delete patch.passwordHash; // set passwords through their own endpoint only
  const row = await update<Row>(collection, id, patch);
  if (!row) return NextResponse.json({ ok: false, error: "Not found" }, { status: 404 });
  await log(admin.email, `Updated ${collection.replace(/s$/, "")}`, String(row.name || row.title || row.clientId || id));
  return NextResponse.json({ ok: true, row });
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ collection: string; id: string }> }) {
  let admin;
  try {
    admin = await requireAdmin();
  } catch (r) {
    return r as Response;
  }
  const { collection, id } = await params;
  if (!isAllowed(collection)) return NextResponse.json({ ok: false, error: "Unknown collection" }, { status: 404 });

  if (collection === "documents") {
    const doc = await get<DocumentRow>("documents", id);
    if (doc?.storageKey) await deleteFile(doc.storageKey);
  }
  const ok = await remove(collection, id);
  if (!ok) return NextResponse.json({ ok: false, error: "Not found" }, { status: 404 });
  await log(admin.email, `Deleted from ${collection}`, id);
  return NextResponse.json({ ok: true });
}
