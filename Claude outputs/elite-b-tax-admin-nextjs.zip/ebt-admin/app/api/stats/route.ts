import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/auth";
import { stats } from "@/lib/db";

export const dynamic = "force-dynamic";

/** GET /api/stats — dashboard counters */
export async function GET() {
  try {
    await requireAdmin();
  } catch (r) {
    return r as Response;
  }
  return NextResponse.json({ ok: true, stats: await stats() });
}
