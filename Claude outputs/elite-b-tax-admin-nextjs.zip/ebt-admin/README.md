# Elite B Tax Services — Admin Dashboard

A real admin application: **Next.js 15 (App Router) + TypeScript**, with its own REST API,
cookie sessions, hashed passwords and real file uploads. Runs on its own, separate from the
public website.

---

## Run it

```bash
npm install
cp .env.example .env.local     # then edit SESSION_SECRET / ADMIN_PASSWORD
npm run dev                    # http://localhost:4000
```

Production:

```bash
npm run build && npm start
```

**Sign in** with the `ADMIN_EMAIL` / `ADMIN_PASSWORD` from `.env.local`
(defaults: `admin@elitebtax.com` / `admin123`). The database file is created on first run
at `data/db.json`, seeded with 10 sample clients and their documents.
Delete that file to start over.

---

## Pages (left sidebar)

| Group | Page | Route |
|---|---|---|
| Overview | Dashboard — counters, 6-month chart, recent inquiries, newest clients, activity log | `/` |
| Clients | All Clients (search, filter, sort, add/edit/delete) | `/clients` |
| Clients | Client profile — details + uploads, drafts, finals, upload & download | `/clients/{id}` |
| Clients | Client Documents · Draft Estimations · Final Documents | `/documents` `/drafts` `/finals` |
| Enquiries | Leads · Website Inquiries | `/leads` `/inquiries` |
| Website content | CMS Pages · Home Banners · Services & Pricing · Tax Notes | `/cms-pages` `/banners` `/services` `/tax-notes` |
| Administration | Employees · Admin Logs · Settings | `/employees` `/logs` `/settings` |

Every table has search, sorting, filters, pagination and CSV export.
Client IDs are generated automatically as `EBT-2026-0001`, `EBT-2026-0002`, …

---

## REST API

All routes require the session cookie; without it they return `401`.

| Method | Route | Purpose |
|---|---|---|
| POST | `/api/auth/login` | `{ email, password }` → sets the session cookie |
| POST | `/api/auth/logout` | Clears the session |
| GET | `/api/{collection}` | List rows. Filters: `?q=&limit=&kind=&status=&clientId=&taxYear=&role=` |
| POST | `/api/{collection}` | Create a row (JSON body) |
| GET | `/api/{collection}/{id}` | One row |
| PATCH | `/api/{collection}/{id}` | Update a row |
| DELETE | `/api/{collection}/{id}` | Delete a row |
| POST | `/api/uploads` | multipart: `file`, `clientId`, `kind=upload\|draft\|final`, `taxYear`, `type`, `note` |
| GET | `/api/files/{documentId}` | Download the stored file (`?view=1` opens inline) |
| GET | `/api/stats` | Dashboard counters |
| GET/PATCH | `/api/settings` | Company settings |

`{collection}` is one of: `clients`, `documents`, `leads`, `inquiries`, `cmsPages`,
`banners`, `services`, `taxNotes`, `employees`, `logs`.

Example:

```bash
curl -c cookies.txt -X POST localhost:4000/api/auth/login \
  -H 'content-type: application/json' \
  -d '{"email":"admin@elitebtax.com","password":"admin123"}'

curl -b cookies.txt localhost:4000/api/clients?limit=5
```

---

## Swapping in your own backend

Two clean options:

**1. Keep these API routes, change the storage.** Everything that touches data lives in
`lib/db.ts` (and `lib/storage.ts` for files). Rewrite those functions for PostgreSQL,
MySQL, Prisma or an external service — the pages and API routes stay as they are:

```ts
export async function list<T>(coll: Collection): Promise<T[]> {
  const { rows } = await pool.query(`SELECT * FROM ${table(coll)} ORDER BY created_at DESC`);
  return rows as T[];
}
```

**2. Point the UI at your existing API.** The front end only calls
`/api/{collection}`, `/api/uploads`, `/api/files/{id}`, `/api/stats` and `/api/settings`.
Either implement those paths on your server, or add a base URL and change the `fetch`
calls in `components/data-table.tsx`, `components/upload-form.tsx`,
`components/settings-forms.tsx` and `components/shell.tsx`.

Adding a page takes one entry in `lib/sections.ts` (columns, form fields, filters) — the
sidebar link, table, add/edit modals and CSV export come from that config.

---

## Security notes

- Passwords are hashed with **scrypt** (`lib/auth.ts`); hashes are never sent to the browser.
- The session cookie is **httpOnly**, `sameSite=lax`, signed with HMAC-SHA256, valid 8 hours,
  and `secure` in production. **Set a long random `SESSION_SECRET`** before deploying —
  the app refuses to start in production without one.
- `middleware.ts` bounces unauthenticated requests; every API route re-checks the signature
  server-side (`requireAdmin`).
- Uploads are limited to 15 MB and to PDF/JPG/PNG/HEIC/DOC(X)/XLS(X)/CSV, stored outside
  `public/` in `data/uploads`, and served only through the authenticated download route.
- Before going live: put it behind HTTPS, add rate limiting on `/api/auth/login`, and give
  each employee their own login (the `employees` collection already has a `passwordHash`
  field — add a "set password" route under `app/api/`).

---

## Project layout

```
app/
  layout.tsx           html shell
  admin-layout.tsx     session check + sidebar wrapper
  page.tsx             dashboard
  [section]/page.tsx   every list page, from lib/sections.ts
  clients/[id]/page.tsx client profile
  settings/page.tsx    settings forms
  login/page.tsx       sign-in
  api/…                the REST API above
components/
  shell.tsx            sidebar, topbar, time-zone clocks
  data-table.tsx       table with search/sort/filter/pagination/CSV
  modal.tsx            modal + generated forms + confirm dialog
  upload-form.tsx      real file upload
  client-documents.tsx document groups on the client page
  settings-forms.tsx   settings
lib/
  db.ts                data layer  ← swap this for your database
  storage.ts           file storage ← swap for S3/GCS
  auth.ts              scrypt hashing + signed session cookie
  sections.ts          page/table/form definitions
  types.ts             shared types
data/                  created at runtime: db.json + uploads/ (git-ignored)
```

Brand colors: red `#C8102E`, dark `#1B1F24`, page background `#F4F5F7` (`app/globals.css`).
