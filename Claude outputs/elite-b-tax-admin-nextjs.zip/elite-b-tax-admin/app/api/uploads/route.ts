import { NextResponse } from "next/server";
import { randomUUID } from "node:crypto";
import path from "node:path";
import { requireAdmin } from "@/lib/auth";
import { create, get, log } from "@/lib/db";
import { saveFile } from "@/lib/storage";
import { liveEnabled, liveUpload } from "@/lib/live";
import type { Client, DocumentRow } from "@/lib/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const MAX_BYTES = 15 * 1024 * 1024;
const ALLOWED_EXT = [".pdf", ".jpg", ".jpeg", ".png", ".heic", ".doc", ".docx", ".xls", ".xlsx", ".csv"];

/**
 * POST /api/uploads  (multipart/form-data)
 * fields: file, clientId, kind=upload|draft|final, taxYear, type, note
 */
export async function POST(req: Request) {
  let admin;
  try {
    admin = await requireAdmin();
  } catch (r) {
    return r as Response;
  }

  const form = await req.formData().catch(() => null);
  if (!form) return NextResponse.json({ ok: false, error: "Invalid upload." }, { status: 400 });

  const file = form.get("file");
  if (!(file instanceof File) || file.size === 0) return NextResponse.json({ ok: false, error: "No file received." }, { status: 400 });
  if (file.size > MAX_BYTES) return NextResponse.json({ ok: false, error: "File is larger than 15 MB." }, { status: 413 });

  const ext = path.extname(file.name).toLowerCase();
  if (!ALLOWED_EXT.includes(ext)) return NextResponse.json({ ok: false, error: "Unsupported file type." }, { status: 415 });

  const clientId = String(form.get("clientId") || "");
  const client = await get<Client>("clients", clientId);
  if (!client) return NextResponse.json({ ok: false, error: "Choose a client." }, { status: 400 });

  // Live mode: the file goes straight into the client's dashboard on the website,
  // which also emails them that a new document is waiting.
  if (liveEnabled()) {
    const kindLive = String(form.get("kind") || "draft");
    if (kindLive !== "draft" && kindLive !== "final") {
      return NextResponse.json({ ok: false, error: "Only drafts and final documents can be shared with a client." }, { status: 400 });
    }
    try {
      const row = await liveUpload(clientId, form);
      await log(admin.email, `Shared ${kindLive}`, `${client.firstName} ${client.lastName} — ${file.name}`);
      return NextResponse.json({ ok: true, row }, { status: 201 });
    } catch (err) {
      return NextResponse.json({ ok: false, error: (err as Error).message }, { status: 502 });
    }
  }

  const kindRaw = String(form.get("kind") || "draft");
  const kind = (["upload", "draft", "final"].includes(kindRaw) ? kindRaw : "draft") as DocumentRow["kind"];

  const id = randomUUID();
  const storageKey = `${clientId}/${id}${ext}`;
  await saveFile(storageKey, Buffer.from(await file.arrayBuffer()));

  const row = await create<DocumentRow>("documents", {
    clientId,
    kind,
    name: file.name.slice(0, 200),
    type: String(form.get("type") || (kind === "final" ? "Final return" : kind === "draft" ? "Draft estimation" : "Client upload")),
    taxYear: String(form.get("taxYear") || ""),
    sizeKb: Math.round(file.size / 1024),
    storageKey,
    note: String(form.get("note") || ""),
    status: kind === "draft" ? "awaiting_review" : "",
    uploadedBy: kind === "upload" ? "client" : "staff",
  });

  await log(admin.email, `Uploaded ${kind}`, `${client.firstName} ${client.lastName} — ${file.name}`);
  return NextResponse.json({ ok: true, row }, { status: 201 });
}
