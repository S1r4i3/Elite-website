import "server-only";
import type { Client, Collection, DocumentRow, Row } from "./types";

/**
 * Live connection to the Elite B Tax website.
 *
 * When SITE_API_URL and ADMIN_API_TOKEN are set, the collections that the website
 * owns — clients, documents, leads, inquiries — are read from and written to the
 * website's /api/v1/admin API instead of this app's local JSON file. Everything
 * else (CMS pages, banners, services, tax notes, employees, logs, settings) stays
 * local to this admin app.
 *
 * Leave the two variables unset to run this dashboard on its own seeded demo data.
 */

export const LIVE_COLLECTIONS: Collection[] = ["clients", "documents", "leads", "inquiries"];

export const liveEnabled = () => Boolean(process.env.SITE_API_URL && process.env.ADMIN_API_TOKEN);
export const isLive = (coll: Collection) => liveEnabled() && LIVE_COLLECTIONS.includes(coll);

const base = () => (process.env.SITE_API_URL || "").replace(/\/$/, "");

export async function siteFetch(path: string, init: RequestInit = {}) {
  const res = await fetch(`${base()}/api/v1/admin${path}`, {
    ...init,
    headers: { ...(init.headers || {}), authorization: `Bearer ${process.env.ADMIN_API_TOKEN}` },
    cache: "no-store",
  });
  return res;
}

async function siteJson<T>(path: string, init: RequestInit = {}): Promise<T> {
  const res = await siteFetch(path, init);
  const json = (await res.json().catch(() => ({}))) as { ok?: boolean; error?: string } & T;
  if (!res.ok || json.ok === false) throw new Error(json.error || `Website API error (${res.status}) on ${path}`);
  return json;
}

// ───────────────────────────── shape mapping ─────────────────────────────
// The website stores customers and portal documents; this admin app renders
// Client / DocumentRow. These functions translate between the two.

type SiteClient = {
  id: string; clientId: string | null; firstName: string; lastName: string; email: string; phone: string | null;
  dob: string | null; state: string | null; country: string | null; address: string | null;
  emailVerified: boolean; lastLoginAt: string | null; createdAt: string;
};

type SiteDocument = {
  id: string; clientId: string; kind: "upload" | "draft" | "final"; name: string; sizeKb: number;
  category: string | null; taxYear: string | null; note: string | null; status: string | null;
  clientComment: string | null; createdAt: string; updatedAt: string;
};

const toClient = (c: SiteClient): Client => ({
  id: c.id,
  clientId: c.clientId || "—",
  firstName: c.firstName,
  lastName: c.lastName,
  email: c.email,
  phone: c.phone || "",
  dob: c.dob || "",
  address: c.address || "",
  state: c.state || "",
  country: c.country || "",
  service: "—",
  taxYear: String(new Date(c.createdAt).getFullYear() - 1),
  status: c.emailVerified ? "active" : "pending",
  lastLoginAt: c.lastLoginAt,
  createdAt: c.createdAt,
});

const toDocument = (d: SiteDocument): DocumentRow => ({
  id: d.id,
  clientId: d.clientId,
  kind: d.kind,
  name: d.name,
  type: d.category || (d.kind === "final" ? "Final return" : d.kind === "draft" ? "Draft estimation" : "Client upload"),
  taxYear: d.taxYear || "",
  sizeKb: d.sizeKb,
  storageKey: `site:${d.id}`,
  note: d.note || "",
  status: (d.status || "") as DocumentRow["status"],
  clientComment: d.clientComment || "",
  uploadedBy: d.kind === "upload" ? "client" : "staff",
  createdAt: d.createdAt,
  updatedAt: d.updatedAt,
});

// ───────────────────────────── read / write ─────────────────────────────

export async function liveList<T extends Row>(coll: Collection): Promise<T[]> {
  switch (coll) {
    case "clients": {
      const { rows } = await siteJson<{ rows: SiteClient[] }>("/clients?limit=500");
      return rows.map(toClient) as unknown as T[];
    }
    case "documents": {
      const { rows } = await siteJson<{ rows: SiteDocument[] }>("/documents?limit=500");
      return rows.map(toDocument) as unknown as T[];
    }
    case "leads": {
      const { rows } = await siteJson<{ rows: Row[] }>("/leads?limit=500");
      return rows as T[];
    }
    case "inquiries": {
      const { rows } = await siteJson<{ rows: Row[] }>("/inquiries?limit=500");
      return rows as T[];
    }
    default:
      return [];
  }
}

export async function liveGet<T extends Row>(coll: Collection, id: string): Promise<T | null> {
  try {
    if (coll === "clients") {
      const { client } = await siteJson<{ client: SiteClient }>(`/clients/${id}`);
      return toClient(client) as unknown as T;
    }
    if (coll === "documents") {
      const { document } = await siteJson<{ document: SiteDocument }>(`/documents/${id}`);
      return toDocument(document) as unknown as T;
    }
    if (coll === "leads") {
      const { lead } = await siteJson<{ lead: Row }>(`/leads/${id}`);
      return lead as T;
    }
    const rows = await liveList<T>(coll);
    return rows.find((r) => r.id === id) ?? null;
  } catch {
    return null;
  }
}

export async function liveUpdate<T extends Row>(coll: Collection, id: string, patch: Record<string, unknown>): Promise<T | null> {
  const body = JSON.stringify(patch);
  const headers = { "content-type": "application/json" };
  if (coll === "clients") {
    const { client } = await siteJson<{ client: SiteClient }>(`/clients/${id}`, { method: "PATCH", headers, body });
    return toClient(client) as unknown as T;
  }
  if (coll === "documents") {
    const { document } = await siteJson<{ document: SiteDocument }>(`/documents/${id}`, { method: "PATCH", headers, body });
    return toDocument(document) as unknown as T;
  }
  if (coll === "leads") {
    const { lead } = await siteJson<{ lead: Row }>(`/leads/${id}`, { method: "PATCH", headers, body });
    return lead as T;
  }
  throw new Error(`${coll} is managed on the website and can't be edited here.`);
}

export async function liveRemove(coll: Collection, id: string): Promise<boolean> {
  if (coll !== "documents") throw new Error(`${coll} records live on the website and can't be deleted from this dashboard.`);
  await siteJson(`/documents/${id}`, { method: "DELETE" });
  return true;
}

/** Uploads a draft/final straight into the client's dashboard on the website. */
export async function liveUpload(clientId: string, form: FormData) {
  const res = await siteFetch(`/clients/${clientId}/documents`, { method: "POST", body: form });
  const json = (await res.json().catch(() => ({}))) as { ok?: boolean; error?: string; document?: SiteDocument };
  if (!res.ok || !json.ok || !json.document) throw new Error(json.error || `Upload failed (${res.status})`);
  return toDocument(json.document);
}

/** Streams a stored file back from the website. */
export async function liveFile(documentId: string, inline: boolean) {
  return siteFetch(`/documents/${documentId}/file${inline ? "?view=1" : ""}`);
}

export async function liveStats() {
  const { stats } = await siteJson<{
    stats: {
      clients: number; inquiries: number; leads: number;
      leadsByStatus: Record<string, number>;
      documents: { upload: number; draft: number; final: number };
    };
  }>("/stats");
  return stats;
}
