import "server-only";
import { promises as fs } from "node:fs";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { hashPassword } from "./auth";
import type { Client, Collection, DB, DocumentRow, Inquiry, Row, Settings } from "./types";
import { SERVICES } from "./types";
import { isLive, liveEnabled, liveGet, liveList, liveRemove, liveStats, liveUpdate } from "./live";

/**
 * JSON-file data store.
 *
 * This is the ONLY file that touches storage. To move to PostgreSQL / MySQL / an
 * external API, rewrite the exported functions below — the API routes and the UI
 * never read the file directly. See README.md → "Swapping in your own backend".
 */

const DATA_DIR = path.resolve(process.cwd(), "data");
const DB_FILE = path.join(DATA_DIR, "db.json");

let cache: DB | null = null;
let queue: Promise<unknown> = Promise.resolve();

const iso = (daysAgo: number, hour = 10) => {
  const d = new Date();
  d.setDate(d.getDate() - daysAgo);
  d.setHours(hour, (daysAgo * 7) % 60, 0, 0);
  return d.toISOString();
};

async function seed(): Promise<DB> {
  const YEAR = new Date().getFullYear();
  const cid = (n: number) => `EBT-${YEAR}-${String(n).padStart(4, "0")}`;
  const people: Array<[string, string, string, string, string, string, string, Client["status"]]> = [
    ["Ravi", "Teja", "ravi.teja@example.com", "+1 302 555 0111", "Texas", "United States", "Federal Tax Filing", "active"],
    ["Priya", "Sharma", "priya.sharma@example.com", "+1 302 555 0112", "New Jersey", "United States", "FBAR / FATCA", "active"],
    ["Anil", "Kumar", "anil.kumar@example.com", "+91 98765 43210", "Telangana", "India", "Indian / NRI Tax", "active"],
    ["Meera", "Nair", "meera.nair@example.com", "+1 302 555 0114", "California", "United States", "ITIN Services", "pending"],
    ["John", "Miller", "john.miller@example.com", "+1 302 555 0115", "Delaware", "United States", "Corporate Tax", "active"],
    ["Sita", "Rao", "sita.rao@example.com", "+1 302 555 0116", "Illinois", "United States", "State Tax Filing", "active"],
    ["Arjun", "Patel", "arjun.patel@example.com", "+1 302 555 0117", "New York", "United States", "LLC Services", "pending"],
    ["Grace", "Chen", "grace.chen@example.com", "+1 302 555 0118", "Washington", "United States", "Bookkeeping", "active"],
    ["Kiran", "Das", "kiran.das@example.com", "+91 90000 12345", "Karnataka", "India", "Indian / NRI Tax", "inactive"],
    ["Daniel", "Brown", "daniel.brown@example.com", "+1 302 555 0120", "Florida", "United States", "Tax Amendments", "active"],
  ];

  const clients: Client[] = people.map(([firstName, lastName, email, phone, state, country, service, status], i) => ({
    id: randomUUID(),
    clientId: cid(i + 1),
    firstName,
    lastName,
    email,
    phone,
    dob: `19${72 + (i % 20)}-0${(i % 9) + 1}-1${i % 9}`,
    address: `${10 + i} Main Street`,
    state,
    country,
    service,
    taxYear: String(YEAR - 1),
    status,
    lastLoginAt: iso(i % 12),
    createdAt: iso(70 - i * 4),
  }));

  const docTypes = ["W-2", "1099-INT", "1099-NEC", "Prior-year return", "Passport / ID", "Bank statement"];
  const documents: DocumentRow[] = [];
  clients.forEach((c, ci) => {
    for (let k = 0; k <= ci % 3; k++) {
      const t = docTypes[(ci + k) % docTypes.length];
      documents.push({
        id: randomUUID(),
        clientId: c.id,
        kind: "upload",
        name: `${t.replace(/[\/\s]/g, "-")}-${c.lastName}.pdf`,
        type: t,
        taxYear: String(YEAR - 1),
        sizeKb: 140 + ((ci * 31 + k * 47) % 800),
        storageKey: "",
        note: "",
        status: "",
        uploadedBy: "client",
        createdAt: iso(40 - ci * 2 - k),
      });
    }
  });
  clients.slice(0, 5).forEach((c, i) => {
    documents.push({
      id: randomUUID(),
      clientId: c.id,
      kind: "draft",
      name: `Draft-Estimate-${YEAR - 1}-${c.lastName}.pdf`,
      type: "Draft estimation",
      taxYear: String(YEAR - 1),
      sizeKb: 220 + i * 30,
      storageKey: "",
      note: [
        "Estimated federal refund $2,140. Please confirm your dependents.",
        "Balance due $860 — review before we file.",
        "Refund $1,020 after the education credit.",
        "Includes FBAR reporting for two accounts.",
        "State return still pending — federal draft attached.",
      ][i],
      status: (["awaiting_review", "approved", "changes_requested", "awaiting_review", "approved"] as const)[i],
      clientComment: i === 2 ? "I also have a 1099-INT from my savings account." : "",
      uploadedBy: "staff",
      createdAt: iso(16 - i * 2),
    });
  });
  clients.slice(0, 3).forEach((c, i) => {
    documents.push({
      id: randomUUID(),
      clientId: c.id,
      kind: "final",
      name: `Form-1040-${YEAR - 1}-${c.lastName}.pdf`,
      type: "Final return",
      taxYear: String(YEAR - 1),
      sizeKb: 400 + i * 40,
      storageKey: "",
      note: "Accepted by the IRS.",
      status: "",
      uploadedBy: "staff",
      createdAt: iso(7 - i * 2),
    });
  });

  const adminEmail = process.env.ADMIN_EMAIL || "admin@elitebtax.com";
  const adminHash = await hashPassword(process.env.ADMIN_PASSWORD || "admin123");

  return {
    settings: {
      companyName: "Elite B Tax Services",
      taxYear: String(YEAR),
      phoneUs: "+1 (302) 202-2139",
      phoneIn: "+91 99127 62149",
      whatsapp: "+91 99127 62149",
      email: "support@elitebtax.com",
      address: "8 The Green, Ste A, Dover, Delaware 19901, US",
      facebook: "",
      instagram: "",
      linkedin: "",
      youtube: "",
      seoTitle: "Elite B Tax Services — U.S. & India Tax Filing",
      seoDescription: "Individual, business and U.S. + India tax services, explained in plain language.",
    },
    clients,
    documents,
    leads: [
      { id: randomUUID(), name: "Vikram Singh", email: "vikram@example.com", phone: "+1 302 555 0190", service: "Corporate Tax", taxYear: String(YEAR - 1), message: "S-corp return plus bookkeeping.", status: "new", createdAt: iso(1, 10) },
      { id: randomUUID(), name: "Nisha Gupta", email: "nisha@example.com", phone: "+1 302 555 0191", service: "ITIN Services", taxYear: String(YEAR - 1), message: "ITIN for spouse and child.", status: "contacted", createdAt: iso(3, 12) },
      { id: randomUUID(), name: "Peter Adams", email: "peter@example.com", phone: "+1 302 555 0192", service: "Federal Tax Filing", taxYear: String(YEAR - 1), message: "", status: "qualified", createdAt: iso(5, 15) },
      { id: randomUUID(), name: "Divya Menon", email: "divya@example.com", phone: "+91 99000 11223", service: "Indian / NRI Tax", taxYear: String(YEAR - 1), message: "US + India filing this year.", status: "converted", createdAt: iso(9, 13) },
    ],
    inquiries: [
      { id: randomUUID(), name: "Rahul Verma", phone: "+91 99887 76655", message: "Need help filing ITR for FY 2024-25.", page: "/", createdAt: iso(1, 9) },
      { id: randomUUID(), name: "Laura Smith", phone: "+1 302 555 0180", message: "Do you handle multi-state returns?", page: "/tax-services", createdAt: iso(2, 14) },
      { id: randomUUID(), name: "Suresh Babu", phone: "+91 91234 56780", message: "FBAR filing for 3 foreign accounts.", page: "/fbar", createdAt: iso(4, 11) },
    ],
    cmsPages: [
      { id: randomUUID(), title: "Welcome to Elite B Tax", slug: "/", body: "Your taxes. Done right. Without the stress.", createdAt: iso(60) },
      { id: randomUUID(), title: "Federal Refund Status", slug: "/refund-status/federal", body: "Check your federal refund with the IRS.", createdAt: iso(60) },
      { id: randomUUID(), title: "State Refund Status", slug: "/refund-status/state", body: "State-by-state refund trackers.", createdAt: iso(60) },
      { id: randomUUID(), title: "Pay Federal Taxes Online", slug: "/pay/federal", body: "IRS Direct Pay and EFTPS.", createdAt: iso(59) },
      { id: randomUUID(), title: "Pay State Taxes Online", slug: "/pay/state", body: "State payment portals.", createdAt: iso(59) },
      { id: randomUUID(), title: "Client Tax Questionnaire", slug: "/questionnaire", body: "What we ask before preparing a return.", createdAt: iso(58) },
    ],
    banners: [
      { id: randomUUID(), title: "Your Taxes. Done Right.", subtitle: "Professional tax preparation without the stress.", cta: "Get Started", link: "/get-started", active: "true", createdAt: iso(20) },
      { id: randomUUID(), title: "U.S. + India Tax Under One Roof", subtitle: "One team for both countries.", cta: "Indian Tax Services", link: "/indian-tax-services", active: "true", createdAt: iso(30) },
    ],
    services: SERVICES.map((name, i) => ({
      id: randomUUID(),
      name,
      price: [149, 99, 199, 129, 179, 299, 349, 279, 499, 249, 199, 229][i] ?? 199,
      active: "true",
      createdAt: iso(40 + i),
    })),
    taxNotes: [
      { id: randomUUID(), title: "Standard deduction", body: "Confirm the current year's figures against IRS Pub 501 before filing.", createdAt: iso(12) },
      { id: randomUUID(), title: "FBAR deadline", body: "April 15, with an automatic extension to October 15.", createdAt: iso(25) },
      { id: randomUUID(), title: "ITIN renewals", body: "ITINs unused on a return for 3 years expire.", createdAt: iso(38) },
    ],
    employees: [
      { id: randomUUID(), name: "Super Admin", email: adminEmail, phone: "+1 302 202 2139", role: "Super Admin", status: "active", passwordHash: adminHash, createdAt: iso(300) },
      { id: randomUUID(), name: "Deepa M.", email: "deepa@elitebtax.com", phone: "+91 90000 22334", role: "Preparer", status: "active", createdAt: iso(120) },
      { id: randomUUID(), name: "Alex Turner", email: "alex@elitebtax.com", phone: "+1 302 555 0170", role: "Reviewer", status: "active", createdAt: iso(80) },
    ],
    logs: [{ id: randomUUID(), who: "system", action: "Database created", detail: "Seeded with sample data", createdAt: new Date().toISOString() }],
  };
}

async function read(): Promise<DB> {
  if (cache) return cache;
  try {
    cache = JSON.parse(await fs.readFile(DB_FILE, "utf8")) as DB;
  } catch {
    cache = await seed();
    await write(cache);
  }
  return cache;
}

async function write(db: DB) {
  await fs.mkdir(DATA_DIR, { recursive: true });
  const tmp = `${DB_FILE}.${process.pid}.tmp`;
  await fs.writeFile(tmp, JSON.stringify(db, null, 2));
  await fs.rename(tmp, DB_FILE);
  cache = db;
}

/** Serializes writes so concurrent requests can't clobber each other. */
function mutate<T>(fn: (db: DB) => T | Promise<T>): Promise<T> {
  const run = queue.then(async () => {
    const db = await read();
    const result = await fn(db);
    await write(db);
    return result;
  });
  queue = run.catch(() => undefined);
  return run;
}

/* ── Public API ─────────────────────────────────────────── */

export const getSettings = async (): Promise<Settings> => (await read()).settings;

export const saveSettings = (patch: Partial<Settings>) =>
  mutate((db) => {
    Object.assign(db.settings, patch);
    return db.settings;
  });

export async function list<T extends Row>(coll: Collection): Promise<T[]> {
  if (isLive(coll)) return liveList<T>(coll);
  const db = await read();
  return [...(db[coll] as unknown as T[])].sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
}

export async function get<T extends Row>(coll: Collection, id: string): Promise<T | null> {
  if (isLive(coll)) return liveGet<T>(coll, id);
  const db = await read();
  return ((db[coll] as unknown as T[]).find((r) => r.id === id) as T) ?? null;
}

export function create<T extends Row>(coll: Collection, data: Record<string, unknown>): Promise<T> {
  if (isLive(coll)) {
    // Clients register themselves on the website; leads and inquiries arrive from its forms.
    throw new Error(`${coll} are created on the website, not here.`);
  }
  return mutate((db) => {
    const row = { id: randomUUID(), createdAt: new Date().toISOString(), ...data } as unknown as T;
    (db[coll] as unknown as T[]).unshift(row);
    return row;
  });
}

export function update<T extends Row>(coll: Collection, id: string, patch: Record<string, unknown>): Promise<T | null> {
  if (isLive(coll)) return liveUpdate<T>(coll, id, patch);
  return mutate((db) => {
    const row = (db[coll] as unknown as T[]).find((r) => r.id === id);
    if (!row) return null;
    Object.assign(row, patch, { updatedAt: new Date().toISOString() });
    return row;
  });
}

export function remove(coll: Collection, id: string): Promise<boolean> {
  if (isLive(coll)) return liveRemove(coll, id);
  return mutate((db) => {
    const before = (db[coll] as Row[]).length;
    (db[coll] as Row[]) = (db[coll] as Row[]).filter((r) => r.id !== id);
    return (db[coll] as Row[]).length < before;
  });
}

/** Writes an entry to the admin activity log. */
export function log(who: string, action: string, detail = "") {
  return mutate((db) => {
    db.logs.unshift({ id: randomUUID(), who, action, detail, createdAt: new Date().toISOString() });
    db.logs = db.logs.slice(0, 1000);
  });
}

/** Next client number for the current taxation year, e.g. EBT-2026-0011. */
export function nextClientId() {
  return mutate((db) => {
    const prefix = `EBT-${db.settings.taxYear}-`;
    const max = db.clients.reduce((m, c) => (c.clientId?.startsWith(prefix) ? Math.max(m, parseInt(c.clientId.slice(prefix.length), 10) || 0) : m), 0);
    return prefix + String(max + 1).padStart(4, "0");
  });
}

export async function findEmployeeByEmail(email: string) {
  const db = await read();
  return db.employees.find((e) => e.email.toLowerCase() === email.toLowerCase()) ?? null;
}

/** Dashboard counters + the last 6 months of document activity. */
export async function stats() {
  const db = await read();
  const live = liveEnabled() ? await liveStats().catch(() => null) : null;
  const clients = live ? [] : db.clients;
  const documents = live ? await liveList<DocumentRow>("documents").catch(() => []) : db.documents;
  const inquiries: Inquiry[] = live ? await liveList<Inquiry>("inquiries").catch(() => []) : db.inquiries;
  const months: { label: string; key: string; n: number }[] = [];
  for (let i = 5; i >= 0; i--) {
    const d = new Date();
    d.setMonth(d.getMonth() - i, 1);
    months.push({ label: d.toLocaleString("en-US", { month: "short" }), key: `${d.getFullYear()}-${d.getMonth()}`, n: 0 });
  }
  for (const doc of documents) {
    const d = new Date(doc.createdAt);
    const m = months.find((x) => x.key === `${d.getFullYear()}-${d.getMonth()}`);
    if (m) m.n++;
  }
  const recentClients = live ? (await liveList<Client>("clients").catch(() => [])).slice(0, 6) : [...clients].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 6);
  return {
    live: Boolean(live),
    clients: live ? live.clients : clients.length,
    uploads: documents.filter((d) => d.kind === "upload").length,
    draftsAwaiting: documents.filter((d) => d.kind === "draft" && d.status === "awaiting_review").length,
    finals: documents.filter((d) => d.kind === "final").length,
    newLeads: live ? live.leadsByStatus?.new ?? 0 : db.leads.filter((l) => l.status === "new").length,
    inquiries: live ? live.inquiries : inquiries.length,
    months,
    recentClients,
    recentInquiries: [...inquiries].sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt))).slice(0, 5),
    recentLogs: db.logs.slice(0, 6),
    taxYear: db.settings.taxYear,
    companyName: db.settings.companyName,
  };
}
